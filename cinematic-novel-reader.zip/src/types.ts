export interface Character {
  id: string;
  name: string;
  role: 'Protagonist' | 'Antagonist' | 'Companion' | 'Deuteragonist';
  faction: string;
  description: string;
  affinity: string; // e.g. "Chronos Weaver", "Gravity Aegis"
  avatar: string; // Initial letters or miniature illustration
  cardImage: string; // Thematic background accent
  stats: {
    power: number;
    intellect: number;
    resonance: number;
  };
}

export interface Faction {
  id: string;
  name: string;
  description: string;
  region: string;
  sigil: string;
}

export interface Chapter {
  id: string;
  number: number;
  title: string;
  content: string[]; // split in comfortable paragraph blocks
  readingTime: string;
  publishDate: string;
  likes: number;
  commentsCount: number;
  isLocked: boolean;
  volumeId: number;
  volumeName: string;
  summary: string;
}

export interface Reply {
  id: string;
  author: string;
  avatar: string;
  content: string;
  timestamp: string;
  likes: number;
  isLikedByUser?: boolean;
}

export interface Comment {
  id: string;
  author: string;
  avatar: string;
  role?: 'Reader' | 'VIP Reader' | 'Author' | 'Moderator';
  content: string;
  timestamp: string;
  likes: number;
  replies: Reply[];
  isPinned: boolean;
  isLikedByUser?: boolean;
}

export interface Novel {
  title: string;
  subtitle: string;
  coverImage: string;
  author: string;
  authorBio: string;
  authorAvatar: string;
  authorWorksCount: number;
  authorFollowers: number;
  rating: number;
  views: string;
  likes: string;
  language: string;
  status: 'Ongoing' | 'Completed' | 'Hiatus';
  totalChapters: number;
  readingTime: string;
  description: string;
  genres: string[];
  tags: string[];
  synopsis: string;
  timeline: string;
  worldInfo: {
    cosmos: string;
    magicSystem: string;
    loreText: string;
  };
  mainThemes: string[];
  storyHighlights: string[];
}

export interface ReaderSettings {
  fontSize: number; // in pixels, e.g. 16, 18, 20, 22, 24, 26
  lineHeight: number; // e.g. 1.5, 1.7, 1.9, 2.1
  theme: 'dark' | 'sepia' | 'light';
  fontFamily: 'serif' | 'sans' | 'mono';
  width: 'narrow' | 'medium' | 'wide';
  fullscreen: boolean;
  backgroundGlow: boolean;
}

export interface Recommendation {
  id: string;
  title: string;
  rating: number;
  coverImage: string;
  genres: string[];
  shortDescription: string;
  author: string;
  views: string;
}
