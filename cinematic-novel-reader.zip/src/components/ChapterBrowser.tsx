import React, { useState, useMemo } from 'react';
import { motion } from 'motion/react';
import { Search, ListFilter, Play, CheckCircle2, Lock, Flame, ThumbsUp, MessageSquare, Clock, HelpCircle } from 'lucide-react';
import { Chapter } from '../types';

interface ChapterBrowserProps {
  chapters: Chapter[];
  completedChapterIds: string[];
  activeChapterId: string | null;
  onSelectChapter: (chapterId: string) => void;
  onLockAlert: (chapterTitle: string) => void;
}

export default function ChapterBrowser({ 
  chapters, 
  completedChapterIds, 
  activeChapterId, 
  onSelectChapter,
  onLockAlert 
}: ChapterBrowserProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedVolume, setSelectedVolume] = useState<string>('All');

  // Find unique volumes
  const volumes = useMemo(() => {
    const list = new Set(chapters.map(c => c.volumeName));
    return ['All', ...Array.from(list)];
  }, [chapters]);

  // Filtered chapter list
  const filteredChapters = useMemo(() => {
    return chapters.filter(chap => {
      const matchesSearch = chap.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            chap.number.toString().includes(searchQuery);
      const matchesVolume = selectedVolume === 'All' || chap.volumeName === selectedVolume;
      return matchesSearch && matchesVolume;
    });
  }, [chapters, searchQuery, selectedVolume]);

  // Find latest chapter
  const latestChapter = useMemo(() => {
    return [...chapters].sort((a, b) => b.number - a.number)[0];
  }, [chapters]);

  // Find continue reading chapter
  const continueReadingChapter = useMemo(() => {
    if (activeChapterId) {
      return chapters.find(c => c.id === activeChapterId);
    }
    // Default to the first uncompleted chapter
    const firstUncompleted = chapters.find(c => !completedChapterIds.includes(c.id));
    return firstUncompleted || chapters[0];
  }, [chapters, activeChapterId, completedChapterIds]);

  return (
    <section id="chapters" className="relative py-24 px-4 md:px-8 lg:px-12 bg-transparent border-b border-white/5">
      {/* Glow overlays */}
      <div className="absolute top-1/3 left-1/4 w-96 h-96 rounded-full bg-indigo-950/10 blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/3 right-1/4 w-96 h-96 rounded-full bg-cyan-950/10 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <span className="text-[11px] font-mono tracking-[0.25em] text-cyan-400 uppercase font-semibold">
            03 / Chronos Codex
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black font-display tracking-tight text-white">
            Chapter Navigation
          </h2>
          <div className="h-1 w-16 bg-cyan-500 mx-auto rounded-full" />
        </div>

        {/* Top Info Banner: Quick Shortcuts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
          
          {/* Quick Info 1: Continue Reading Banner */}
          {continueReadingChapter && (
            <div className="p-5 rounded-2xl glass-panel-heavy border-indigo-500/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-left">
              <div className="space-y-1.5">
                <span className="text-[10px] font-mono uppercase tracking-wider text-indigo-400 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-ping" />
                  Jump Back In
                </span>
                <h4 className="text-base font-hud font-bold text-gray-200">
                  Ch. {continueReadingChapter.number}: {continueReadingChapter.title}
                </h4>
                <p className="text-xs text-gray-400">
                  {continueReadingChapter.summary.slice(0, 85)}...
                </p>
              </div>
              <button
                onClick={() => onSelectChapter(continueReadingChapter.id)}
                className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs text-white font-hud font-bold flex items-center gap-1.5 transition-all cursor-pointer self-stretch sm:self-auto shrink-0 shadow-lg shadow-indigo-500/15"
              >
                <Play size={12} fill="white" />
                CONTINUE
              </button>
            </div>
          )}

          {/* Quick Info 2: Latest Release Highlight */}
          {latestChapter && (
            <div className="p-5 rounded-2xl glass-panel border-white/5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-left">
              <div className="space-y-1.5">
                <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                  <Flame size={12} className="text-amber-400 fill-amber-400/10" />
                  Latest Update
                </span>
                <h4 className="text-base font-hud font-bold text-gray-200">
                  Ch. {latestChapter.number}: {latestChapter.title}
                </h4>
                <p className="text-xs text-gray-400">
                  Published on {latestChapter.publishDate} • Locked Preview
                </p>
              </div>
              <button
                onClick={() => {
                  if (latestChapter.isLocked) {
                    onLockAlert(latestChapter.title);
                  } else {
                    onSelectChapter(latestChapter.id);
                  }
                }}
                className={`px-4 py-2.5 rounded-xl text-xs font-hud font-bold flex items-center gap-1.5 transition-all cursor-pointer self-stretch sm:self-auto shrink-0 border ${
                  latestChapter.isLocked
                    ? 'bg-amber-500/10 text-amber-400 border-amber-500/20 hover:bg-amber-500/20'
                    : 'bg-cyan-600 hover:bg-cyan-500 text-white'
                }`}
              >
                {latestChapter.isLocked ? <Lock size={12} /> : <Play size={12} fill="white" />}
                {latestChapter.isLocked ? "PREVIEW" : "READ NOW"}
              </button>
            </div>
          )}

        </div>

        {/* Search, Filters and Sorting toolbar */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 mb-8 p-4 rounded-xl bg-slate-900/40 border border-white/5">
          
          {/* Search bar */}
          <div className="relative flex-grow max-w-md">
            <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500" />
            <input
              type="text"
              placeholder="Search chapter title or number..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-lg bg-slate-950 border border-white/5 focus:border-cyan-500/50 text-sm font-sans placeholder-gray-500 outline-none transition-colors"
            />
          </div>

          {/* Volume selection slider */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0 scrollbar-none font-hud text-xs">
            <ListFilter size={14} className="text-gray-500 shrink-0" />
            <div className="flex gap-1.5 shrink-0">
              {volumes.map((vol) => (
                <button
                  key={vol}
                  onClick={() => setSelectedVolume(vol)}
                  className={`px-3 py-1.5 rounded-md border transition-all cursor-pointer ${
                    selectedVolume === vol
                      ? 'bg-cyan-900/30 text-cyan-300 border-cyan-500/30 font-medium'
                      : 'bg-black/30 text-gray-400 border-white/5 hover:text-gray-200'
                  }`}
                >
                  {vol === 'All' ? 'All Volumes' : vol.split(':')[0]}
                </button>
              ))}
            </div>
          </div>

        </div>

        {/* Chapters Cards Grid */}
        {filteredChapters.length === 0 ? (
          <div className="py-16 text-center rounded-2xl border border-dashed border-white/5 bg-slate-900/20">
            <HelpCircle size={40} className="text-gray-600 mx-auto mb-3" />
            <p className="text-gray-400 font-sans">No chapters matched your filters.</p>
            <button 
              onClick={() => { setSearchQuery(''); setSelectedVolume('All'); }}
              className="text-xs text-cyan-400 font-hud font-bold mt-2 hover:underline cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {filteredChapters.map((chap, index) => {
              const isActive = chap.id === activeChapterId;
              const isCompleted = completedChapterIds.includes(chap.id);
              
              return (
                <motion.div
                  key={chap.id}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: Math.min(index * 0.05, 0.4) }}
                  onClick={() => {
                    if (chap.isLocked) {
                      onLockAlert(chap.title);
                    } else {
                      onSelectChapter(chap.id);
                    }
                  }}
                  className={`p-5 rounded-2xl text-left cursor-pointer transition-all flex flex-col justify-between border relative overflow-hidden group ${
                    isActive
                      ? 'bg-cyan-950/20 border-cyan-500/50 shadow-[0_8px_25px_-10px_rgba(6,182,212,0.35)]'
                      : 'bg-slate-900/30 border-white/5 hover:bg-slate-900/70 hover:border-cyan-500/25'
                  }`}
                >
                  {/* Glass reflections and shine */}
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.01] to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000 ease-out pointer-events-none" />

                  {/* Top card header */}
                  <div className="flex justify-between items-start gap-4 mb-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">
                          {chap.volumeName.split(':')[0]}
                        </span>
                        {isCompleted && (
                          <span className="inline-flex items-center gap-1 text-[9px] font-mono uppercase bg-emerald-500/10 text-emerald-400 px-1.5 py-0.2 rounded">
                            <CheckCircle2 size={9} /> COMPLETED
                          </span>
                        )}
                        {chap.isLocked && (
                          <span className="inline-flex items-center gap-1 text-[9px] font-mono uppercase bg-amber-500/10 text-amber-400 px-1.5 py-0.2 rounded">
                            <Lock size={9} /> LOCKED
                          </span>
                        )}
                      </div>
                      <h4 className={`text-lg font-hud font-bold tracking-tight transition-colors group-hover:text-cyan-300 ${
                        isActive ? 'text-cyan-400' : 'text-gray-100'
                      }`}>
                        Ch. {chap.number}: {chap.title}
                      </h4>
                    </div>

                    {/* Indicator Icon */}
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border transition-all ${
                      isActive
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400/40 shadow-inner'
                        : chap.isLocked
                          ? 'bg-amber-500/10 text-amber-400 border-amber-500/20 group-hover:bg-amber-500/20'
                          : 'bg-black/40 text-gray-400 border-white/5 group-hover:border-cyan-500/20 group-hover:text-cyan-400'
                    }`}>
                      {chap.isLocked ? <Lock size={13} /> : <Play size={12} fill={isActive ? "currentColor" : "none"} className="ml-0.5" />}
                    </div>
                  </div>

                  {/* Summary */}
                  <p className="text-xs text-gray-400 leading-relaxed font-sans mb-4 group-hover:text-gray-300 transition-colors">
                    {chap.summary}
                  </p>

                  {/* Card bottom: Statistics and publish detail */}
                  <div className="flex items-center justify-between pt-3.5 border-t border-white/5 text-[11px] font-mono text-gray-500">
                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1">
                        <Clock size={11} className="text-gray-600" />
                        {chap.readingTime}
                      </span>
                      <span className="flex items-center gap-1">
                        <ThumbsUp size={11} className="text-gray-600" />
                        {chap.likes}
                      </span>
                      <span className="flex items-center gap-1">
                        <MessageSquare size={11} className="text-gray-600" />
                        {chap.commentsCount}
                      </span>
                    </div>

                    <span className="text-gray-500 group-hover:text-gray-400 transition-colors">
                      {chap.publishDate}
                    </span>
                  </div>

                </motion.div>
              );
            })}
          </div>
        )}

      </div>
    </section>
  );
}
