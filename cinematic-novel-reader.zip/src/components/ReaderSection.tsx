import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Settings2, Type, MoveHorizontal, Maximize2, Minimize2, 
  Bookmark, CheckCircle2, ThumbsUp, Share2, MessageSquare, 
  ChevronLeft, ChevronRight, Sparkles, Volume2, Moon, Sun, Compass 
} from 'lucide-react';
import { Chapter, ReaderSettings } from '../types';

interface ReaderSectionProps {
  chapter: Chapter;
  completedChapterIds: string[];
  onToggleComplete: (chapterId: string) => void;
  onNextChapter: () => void;
  onPrevChapter: () => void;
  hasNextChapter: boolean;
  hasPrevChapter: boolean;
  onToggleBookmark: (chapterId: string) => void;
  isBookmarked: boolean;
}

const DEFAULT_SETTINGS: ReaderSettings = {
  fontSize: 18,
  lineHeight: 1.8,
  theme: 'dark',
  fontFamily: 'serif',
  width: 'medium',
  fullscreen: false,
  backgroundGlow: true
};

export default function ReaderSection({
  chapter,
  completedChapterIds,
  onToggleComplete,
  onNextChapter,
  onPrevChapter,
  hasNextChapter,
  hasPrevChapter,
  onToggleBookmark,
  isBookmarked
}: ReaderSectionProps) {
  const [settings, setSettings] = useState<ReaderSettings>(() => {
    const saved = localStorage.getItem('aetheris_reader_settings');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* fallback */ }
    }
    return DEFAULT_SETTINGS;
  });

  const [scrollProgress, setScrollProgress] = useState(0);
  const [showSettings, setShowSettings] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(chapter.likes);
  const [isNarrating, setIsNarrating] = useState(false);
  const readerRef = useRef<HTMLDivElement>(null);

  // Sync settings with local storage
  useEffect(() => {
    localStorage.setItem('aetheris_reader_settings', JSON.stringify(settings));
  }, [settings]);

  // Sync likes on chapter change
  useEffect(() => {
    setIsLiked(false);
    setLikeCount(chapter.likes);
    setScrollProgress(0);
    // Scroll reader container into view smoothly on change
    if (readerRef.current) {
      readerRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [chapter]);

  // Scroll tracking
  useEffect(() => {
    const handleScroll = () => {
      if (!readerRef.current) return;
      const rect = readerRef.current.getBoundingClientRect();
      const elementHeight = readerRef.current.scrollHeight;
      const windowHeight = window.innerHeight;
      
      // Calculate how far down the reader element we have scrolled
      const scrolled = window.scrollY - (readerRef.current.offsetTop - 60);
      const totalScrollable = elementHeight - windowHeight;
      
      if (totalScrollable <= 0) {
        setScrollProgress(0);
      } else {
        const percentage = Math.min(Math.max((scrolled / totalScrollable) * 100, 0), 100);
        setScrollProgress(percentage);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [chapter]);

  const updateSetting = <K extends keyof ReaderSettings>(key: K, value: ReaderSettings[K]) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  // Text-to-speech toggler (Web Speech API)
  const toggleSpeech = () => {
    if ('speechSynthesis' in window) {
      if (isNarrating) {
        window.speechSynthesis.cancel();
        setIsNarrating(false);
      } else {
        const entireText = chapter.content.join(' ');
        const utterance = new SpeechSynthesisUtterance(entireText);
        utterance.onend = () => setIsNarrating(false);
        utterance.onerror = () => setIsNarrating(false);
        // Set slightly slower cinematic pace
        utterance.rate = 0.95;
        window.speechSynthesis.speak(utterance);
        setIsNarrating(true);
      }
    } else {
      alert('Text to speech is not supported in this browser.');
    }
  };

  // Ensure speech cuts off on unmount
  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const handleLike = () => {
    if (isLiked) {
      setLikeCount(prev => prev - 1);
    } else {
      setLikeCount(prev => prev + 1);
    }
    setIsLiked(!isLiked);
  };

  // Width Class mapper
  const widthClasses = {
    narrow: 'max-w-xl md:px-6',
    medium: 'max-w-3xl md:px-10',
    wide: 'max-w-5xl md:px-16'
  };

  // Font family mapper
  const fontClasses = {
    serif: 'font-serif tracking-normal antialiased',
    sans: 'font-sans tracking-wide font-normal antialiased',
    mono: 'font-mono tracking-tight text-sm leading-relaxed antialiased'
  };

  // Reading Area Theme Class mapper
  const themeClasses = {
    dark: 'theme-reader-dark border-white/5',
    sepia: 'theme-reader-sepia border-[#433422]/10 shadow-[0_4px_30px_rgba(67,52,34,0.05)]',
    light: 'theme-reader-light border-gray-200 shadow-[0_4px_30px_rgba(0,0,0,0.02)]'
  };

  const isCompleted = completedChapterIds.includes(chapter.id);

  return (
    <section 
      ref={readerRef}
      id="reader" 
      className={`relative py-16 px-4 md:px-8 transition-colors duration-500 overflow-hidden ${
        settings.theme === 'dark' 
          ? 'bg-[#05070a]' 
          : settings.theme === 'sepia' 
            ? 'bg-[#faf6f0]' 
            : 'bg-white'
      }`}
    >
      {/* Immersive background spatial glow mapping */}
      {settings.theme === 'dark' && settings.backgroundGlow && (
        <>
          <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-indigo-900/5 blur-3xl pointer-events-none" />
          <div className="absolute bottom-1/4 left-10 w-96 h-96 rounded-full bg-violet-900/5 blur-3xl pointer-events-none" />
        </>
      )}

      {/* Embedded horizontal scroll progress top bar */}
      <div className="fixed top-0 left-0 right-0 h-[3px] bg-indigo-950/40 z-50">
        <div 
          className="h-full bg-gradient-to-r from-cyan-400 via-indigo-500 to-violet-500 shadow-[0_1px_5px_rgba(99,102,241,0.5)]" 
          style={{ width: `${scrollProgress}%` }}
        />
      </div>

      <div className="max-w-7xl mx-auto flex flex-col items-center">
        
        {/* TOP HUD BAR */}
        <div className={`w-full max-w-3xl flex items-center justify-between mb-8 pb-4 border-b ${
          settings.theme === 'dark' ? 'border-white/5 text-gray-400' : 'border-gray-200 text-gray-500'
        } font-hud text-xs`}>
          <div className="flex items-center gap-3">
            <span className="font-semibold tracking-widest text-indigo-500 font-mono">CH. {chapter.number}</span>
            <span className="opacity-50">|</span>
            <span className="truncate max-w-[200px] sm:max-w-none">{chapter.title}</span>
          </div>

          {/* Reading percent */}
          <div className="font-mono text-[10px] uppercase tracking-wider">
            {Math.round(scrollProgress)}% Scrolled
          </div>
        </div>

        {/* PRIMARY IMPRESIBLE TEXT STAGE */}
        <div 
          className={`w-full rounded-3xl border p-8 md:p-14 relative ${widthClasses[settings.width]} ${themeClasses[settings.theme]} transition-all duration-300`}
        >
          {/* Glowing Aura inside Dark reader */}
          {settings.theme === 'dark' && (
            <div className="absolute top-0 right-10 w-44 h-44 rounded-full bg-indigo-500/5 blur-3xl pointer-events-none" />
          )}

          {/* Chapter Metadata inside flow */}
          <div className="text-center mb-12 space-y-4">
            <p className="text-[10px] font-mono tracking-[0.25em] text-indigo-500 uppercase font-semibold">
              {chapter.volumeName}
            </p>
            <h2 className="text-3xl md:text-4xl font-black font-display tracking-tight leading-tight">
              Chapter {chapter.number}: {chapter.title}
            </h2>
            <div className="flex items-center justify-center gap-4 text-xs font-hud opacity-60">
              <span>Published: {chapter.publishDate}</span>
              <span>•</span>
              <span>Estimated: {chapter.readingTime}</span>
            </div>
            <div className="h-px w-20 bg-indigo-500/20 mx-auto mt-6" />
          </div>

          {/* Actual Prose paragraphs with rich styling */}
          <article 
            className={`space-y-6 md:space-y-8 ${fontClasses[settings.fontFamily]} text-left`}
            style={{ 
              fontSize: `${settings.fontSize}px`, 
              lineHeight: settings.lineHeight,
              fontWeight: 300 
            }}
          >
            {chapter.content.map((paragraph, index) => {
              if (index === 0 && paragraph.length > 0 && settings.theme === 'dark') {
                const firstChar = paragraph.charAt(0);
                const restText = paragraph.slice(1);
                return (
                  <p 
                    key={index}
                    className="indent-0 leading-relaxed font-light hover:text-indigo-400/80 transition-colors duration-300 cursor-default"
                  >
                    <span className="text-5xl float-left mr-3 mt-1 text-indigo-400 leading-none font-light">{firstChar}</span>
                    {restText}
                  </p>
                );
              }
              return (
                <p 
                  key={index}
                  className="indent-0 md:indent-4 leading-relaxed font-light hover:text-indigo-400/80 transition-colors duration-300 cursor-default"
                >
                  {paragraph}
                </p>
              );
            })}
          </article>

          {/* End of chapter divider */}
          <div className="my-14 flex flex-col items-center justify-center gap-4">
            <div className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-500/40" />
              <span className="w-8 h-px bg-indigo-500/20" />
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-500" />
              <span className="w-8 h-px bg-indigo-500/20" />
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-500/40" />
            </div>
            <p className="text-xs font-mono tracking-widest uppercase opacity-40">End of Chapter {chapter.number}</p>
          </div>

          {/* CHAPTER COMPLETED MARKER ACTION */}
          <div className="flex flex-col items-center gap-3.5 py-6 px-4 rounded-2xl bg-indigo-500/5 border border-indigo-500/10 max-w-md mx-auto text-center mb-8">
            <p className="text-xs font-hud text-gray-400">Mark this chapter as completed to update your reading log progress:</p>
            <button
              onClick={() => onToggleComplete(chapter.id)}
              className={`px-5 py-2.5 rounded-xl text-xs font-hud font-bold flex items-center gap-2 transition-all cursor-pointer ${
                isCompleted 
                  ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30' 
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white'
              }`}
            >
              <CheckCircle2 size={14} className={isCompleted ? "text-emerald-400" : "text-white"} />
              {isCompleted ? "COMPLETED" : "MARK COMPLETED"}
            </button>
          </div>

          {/* ACTION BAR (Social actions & Pagination) */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-6 pt-8 border-t border-white/5 mt-10">
            
            {/* Quick response stats */}
            <div className="flex items-center gap-2">
              <button 
                onClick={handleLike}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-hud font-medium transition-all cursor-pointer border ${
                  isLiked 
                    ? 'bg-rose-500/10 text-rose-400 border-rose-500/20' 
                    : 'bg-black/20 text-gray-400 border-white/5 hover:bg-black/40 hover:text-gray-200'
                }`}
              >
                <ThumbsUp size={13} className={isLiked ? "fill-rose-400 text-rose-400" : "text-gray-400"} />
                <span>{likeCount} Likes</span>
              </button>

              <button 
                onClick={() => onToggleBookmark(chapter.id)}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-hud font-medium transition-all cursor-pointer border ${
                  isBookmarked 
                    ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' 
                    : 'bg-black/20 text-gray-400 border-white/5 hover:bg-black/40 hover:text-gray-200'
                }`}
              >
                <Bookmark size={13} className={isBookmarked ? "fill-amber-400 text-amber-400" : "text-gray-400"} />
                <span>{isBookmarked ? "Bookmarked" : "Bookmark"}</span>
              </button>

              <button 
                onClick={() => {
                  navigator.clipboard.writeText(window.location.href);
                  alert('Link copied! Share the cosmic word.');
                }}
                className="flex items-center justify-center p-2 rounded-full bg-black/20 text-gray-400 border border-white/5 hover:bg-black/40 hover:text-gray-200 transition-all cursor-pointer"
                title="Copy Shareable Link"
              >
                <Share2 size={13} />
              </button>
            </div>

            {/* Pagination controls */}
            <div className="flex items-center gap-2.5 font-hud">
              <button
                disabled={!hasPrevChapter}
                onClick={onPrevChapter}
                className="px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1 bg-black/30 text-gray-400 hover:text-white border border-white/5 disabled:opacity-20 disabled:pointer-events-none transition-all cursor-pointer active:scale-95"
              >
                <ChevronLeft size={14} />
                PREV
              </button>
              
              <button
                disabled={!hasNextChapter}
                onClick={onNextChapter}
                className="px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white disabled:opacity-20 disabled:pointer-events-none transition-all cursor-pointer active:scale-95"
              >
                NEXT
                <ChevronRight size={14} />
              </button>
            </div>

          </div>

        </div>

        {/* FLOATING HUD READER CONTROLS (Floating right side on Desktop, Floating bottom bar on Mobile) */}
        <div className="fixed bottom-6 right-6 lg:bottom-1/2 lg:-translate-y-1/2 lg:right-8 z-40 flex flex-row lg:flex-col gap-3 p-2 bg-slate-950/85 backdrop-blur-xl rounded-full border border-white/10 shadow-[0_10px_35px_-5px_rgba(0,0,0,0.5)]">
          {/* Settings button */}
          <button
            onClick={() => setShowSettings(!showSettings)}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-all cursor-pointer ${
              showSettings ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
            title="Reader Settings"
          >
            <Settings2 size={16} />
          </button>

          {/* Text to Speech trigger */}
          <button
            onClick={toggleSpeech}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-all cursor-pointer ${
              isNarrating ? 'bg-cyan-600 text-white animate-pulse' : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
            title={isNarrating ? "Stop narration" : "Audio Narration"}
          >
            <Volume2 size={16} />
          </button>

          {/* Toggle background glow (Only relevant in dark theme) */}
          <button
            onClick={() => updateSetting('theme', settings.theme === 'dark' ? 'sepia' : settings.theme === 'sepia' ? 'light' : 'dark')}
            className="w-10 h-10 rounded-full flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/5 transition-all cursor-pointer"
            title="Cycle Reading Palette"
          >
            {settings.theme === 'dark' ? <Moon size={16} /> : settings.theme === 'sepia' ? <Compass size={16} /> : <Sun size={16} />}
          </button>

          {/* Bookmark Trigger */}
          <button
            onClick={() => onToggleBookmark(chapter.id)}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-all cursor-pointer ${
              isBookmarked ? 'text-amber-400' : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
            title={isBookmarked ? "Remove Bookmark" : "Add Bookmark"}
          >
            <Bookmark size={16} className={isBookmarked ? "fill-amber-400" : ""} />
          </button>
        </div>

        {/* READER SETTINGS PANEL MODAL/SHEET overlay */}
        <AnimatePresence>
          {showSettings && (
            <motion.div
              initial={{ opacity: 0, y: 15, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 15, scale: 0.95 }}
              className="fixed bottom-20 right-6 lg:bottom-1/3 lg:right-20 z-40 w-80 p-5 rounded-2xl glass-panel-heavy border-white/10 text-left space-y-5 shadow-[0_20px_50px_rgba(0,0,0,0.7)] text-gray-200 font-hud"
            >
              <div className="flex items-center justify-between border-b border-white/5 pb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-400 flex items-center gap-1.5">
                  <Settings2 size={13} />
                  Display Controls
                </span>
                <button 
                  onClick={() => setShowSettings(false)}
                  className="text-xs text-gray-500 hover:text-gray-300 font-mono"
                >
                  Close
                </button>
              </div>

              {/* Font Size controls */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-medium text-gray-400">
                  <span>Text Size</span>
                  <span className="font-mono">{settings.fontSize}px</span>
                </div>
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => updateSetting('fontSize', Math.max(settings.fontSize - 2, 14))}
                    className="flex-1 py-1.5 rounded bg-slate-900 border border-white/5 hover:border-white/15 text-xs text-center cursor-pointer active:scale-95"
                  >
                    A-
                  </button>
                  <button 
                    onClick={() => updateSetting('fontSize', Math.min(settings.fontSize + 2, 28))}
                    className="flex-1 py-1.5 rounded bg-slate-900 border border-white/5 hover:border-white/15 text-xs text-center cursor-pointer active:scale-95"
                  >
                    A+
                  </button>
                </div>
              </div>

              {/* Font Family selection */}
              <div className="space-y-2">
                <span className="text-xs font-medium text-gray-400 block">Typeface Variant</span>
                <div className="grid grid-cols-3 gap-1.5 text-[11px]">
                  {['serif', 'sans', 'mono'].map((font) => (
                    <button
                      key={font}
                      onClick={() => updateSetting('fontFamily', font as any)}
                      className={`py-1.5 rounded border capitalize transition-all cursor-pointer ${
                        settings.fontFamily === font
                          ? 'bg-indigo-600/30 text-indigo-200 border-indigo-500/40 font-medium'
                          : 'bg-slate-900 text-gray-400 border-white/5 hover:text-gray-200'
                      }`}
                    >
                      {font}
                    </button>
                  ))}
                </div>
              </div>

              {/* Line height selection */}
              <div className="space-y-2">
                <span className="text-xs font-medium text-gray-400 block flex items-center gap-1">
                  <Type size={11} />
                  Spacing Scale
                </span>
                <div className="grid grid-cols-3 gap-1.5 text-[11px]">
                  {([1.5, 1.8, 2.1] as const).map((lh) => (
                    <button
                      key={lh}
                      onClick={() => updateSetting('lineHeight', lh)}
                      className={`py-1.5 rounded border transition-all cursor-pointer ${
                        settings.lineHeight === lh
                          ? 'bg-indigo-600/30 text-indigo-200 border-indigo-500/40 font-medium'
                          : 'bg-slate-900 text-gray-400 border-white/5 hover:text-gray-200'
                      }`}
                    >
                      {lh === 1.5 ? 'Compact' : lh === 1.8 ? 'Balanced' : 'Loose'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Column Width controls */}
              <div className="space-y-2">
                <span className="text-xs font-medium text-gray-400 block flex items-center gap-1">
                  <MoveHorizontal size={11} />
                  Column Margin Width
                </span>
                <div className="grid grid-cols-3 gap-1.5 text-[11px]">
                  {['narrow', 'medium', 'wide'].map((w) => (
                    <button
                      key={w}
                      onClick={() => updateSetting('width', w as any)}
                      className={`py-1.5 rounded border capitalize transition-all cursor-pointer ${
                        settings.width === w
                          ? 'bg-indigo-600/30 text-indigo-200 border-indigo-500/40 font-medium'
                          : 'bg-slate-900 text-gray-400 border-white/5 hover:text-gray-200'
                      }`}
                    >
                      {w}
                    </button>
                  ))}
                </div>
              </div>

              {/* Visual Ambient Glow and Fullscreen switches */}
              <div className="pt-2 border-t border-white/5 flex items-center justify-between">
                <span className="text-xs text-gray-400">Atmosphere Glow</span>
                <button
                  onClick={() => updateSetting('backgroundGlow', !settings.backgroundGlow)}
                  className={`w-10 h-5 rounded-full p-0.5 transition-all duration-300 ${
                    settings.backgroundGlow ? 'bg-indigo-600 flex justify-end' : 'bg-slate-800 flex justify-start'
                  }`}
                >
                  <div className="w-4 h-4 bg-white rounded-full shadow-md" />
                </button>
              </div>

            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}
