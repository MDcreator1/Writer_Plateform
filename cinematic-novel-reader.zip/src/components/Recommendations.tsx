import React from 'react';
import { motion } from 'motion/react';
import { Star, Eye, ChevronRight, Sparkles } from 'lucide-react';
import { Recommendation } from '../types';

interface RecommendationsProps {
  recommendations: Recommendation[];
  onSelectRecommendation: (title: string) => void;
}

export default function Recommendations({ recommendations, onSelectRecommendation }: RecommendationsProps) {
  return (
    <section id="recommendations" className="relative py-24 px-4 md:px-8 lg:px-12 bg-transparent border-b border-white/5 overflow-hidden">
      {/* Subtle glow rings */}
      <div className="absolute top-1/2 right-1/4 w-80 h-80 rounded-full bg-cyan-950/10 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-16 gap-4">
          <div className="space-y-4 text-left">
            <span className="text-[11px] font-mono tracking-[0.25em] text-cyan-400 uppercase font-semibold">
              05 / Echoing Volumes
            </span>
            <h2 className="text-3xl sm:text-4xl font-black font-display tracking-tight text-white">
              Recommended Novels
            </h2>
            <div className="h-1 w-16 bg-cyan-500 rounded-full" />
          </div>

          <span className="text-xs text-gray-500 font-hud tracking-wide hidden sm:block">
            Curated corresponding literature
          </span>
        </div>

        {/* Showcase Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {recommendations.map((rec, index) => (
            <motion.div
              key={rec.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              onClick={() => onSelectRecommendation(rec.title)}
              className="group p-5 rounded-2xl glass-card-interactive flex flex-col justify-between text-left relative cursor-pointer"
            >
              <div className="space-y-4">
                {/* Simulated Book Cover Backdrop Header */}
                <div 
                  className="w-full h-40 rounded-xl flex items-end p-4 relative overflow-hidden border border-white/5 shadow-inner"
                  style={{ background: rec.coverImage }}
                >
                  {/* Hologram glass reflection overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent z-10" />
                  <div className="absolute -inset-y-6 w-10 bg-white/10 blur-md skew-x-12 translate-x-[-200%] group-hover:translate-x-[400%] transition-transform duration-1000 ease-out pointer-events-none z-15" />
                  
                  {/* Quick stats on cover */}
                  <div className="flex justify-between items-center w-full relative z-20 text-[10px] font-mono text-gray-300">
                    <span className="flex items-center gap-1 bg-black/60 px-2 py-0.5 rounded-full border border-white/5">
                      <Star size={10} className="text-amber-400 fill-amber-400/20" />
                      {rec.rating}
                    </span>
                    <span className="flex items-center gap-1 bg-black/60 px-2 py-0.5 rounded-full border border-white/5">
                      <Eye size={10} className="text-cyan-400" />
                      {rec.views}
                    </span>
                  </div>
                </div>

                {/* Text Metadata */}
                <div className="space-y-1.5">
                  <h3 className="text-lg font-hud font-bold text-gray-100 group-hover:text-cyan-300 transition-colors">
                    {rec.title}
                  </h3>
                  <p className="text-xs text-gray-500 font-mono">By {rec.author}</p>
                </div>

                {/* Short synopsis summary */}
                <p className="text-xs text-gray-400 leading-relaxed font-sans font-light">
                  {rec.shortDescription}
                </p>
              </div>

              {/* Genres and CTA button */}
              <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between">
                <div className="flex flex-wrap gap-1">
                  {rec.genres.slice(0, 2).map((g) => (
                    <span key={g} className="text-[10px] px-2 py-0.5 rounded bg-slate-900 border border-white/5 text-gray-400 font-hud">
                      {g}
                    </span>
                  ))}
                </div>

                <span className="text-xs text-cyan-400 font-hud font-bold flex items-center gap-0.5 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all">
                  Inspect
                  <ChevronRight size={14} />
                </span>
              </div>

            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
