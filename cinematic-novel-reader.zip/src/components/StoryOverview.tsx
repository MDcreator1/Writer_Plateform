import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, CalendarRange, Globe2, BookOpenText, Flame, Sparkles, CheckCircle2 } from 'lucide-react';
import { Novel } from '../types';

interface StoryOverviewProps {
  novel: Novel;
}

export default function StoryOverview({ novel }: StoryOverviewProps) {
  const [activeTab, setActiveTab] = useState<'cosmos' | 'magic' | 'lore'>('cosmos');

  return (
    <section id="overview" className="relative py-24 px-4 md:px-8 lg:px-12 bg-transparent border-t border-b border-white/5 overflow-hidden">
      {/* Background visual detail */}
      <div className="absolute top-1/2 left-0 w-80 h-80 rounded-full bg-violet-950/10 blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] rounded-full bg-indigo-950/10 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <span className="text-[11px] font-mono tracking-[0.25em] text-indigo-400 uppercase font-semibold">
            01 / Cosmic Archive
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black font-display tracking-tight text-white">
            Story Overview & World Lore
          </h2>
          <div className="h-1 w-16 bg-indigo-500 mx-auto rounded-full" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
          
          {/* Left: The Synopsis and Story Highlights (Col 1-7) */}
          <div className="lg:col-span-7 space-y-8">
            <div className="p-6 md:p-8 rounded-2xl glass-panel border-white/5 space-y-6">
              <h3 className="text-lg font-hud font-semibold text-gray-200 flex items-center gap-2 border-b border-white/5 pb-4">
                <BookOpenText size={18} className="text-indigo-400" />
                The Synopsis
              </h3>
              <p className="text-base text-gray-300 leading-relaxed font-sans first-letter:text-5xl first-letter:font-display first-letter:font-bold first-letter:text-indigo-400 first-letter:mr-3 first-letter:float-left">
                {novel.synopsis}
              </p>

              {/* Tags and Metadata */}
              <div className="flex flex-wrap items-center gap-2 pt-4 border-t border-white/5">
                <span className="text-xs text-gray-500 font-mono uppercase tracking-wider mr-2">Core Tags:</span>
                {novel.tags.map((tag) => (
                  <span key={tag} className="px-3 py-1 rounded bg-slate-900 border border-white/5 text-xs text-gray-400 font-hud">
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Highlights Grid */}
            <div className="space-y-4">
              <h4 className="text-sm font-hud font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
                <Sparkles size={14} className="text-indigo-400" />
                Story Highlights
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {novel.storyHighlights.map((highlight, index) => (
                  <div key={index} className="flex gap-3 p-4 rounded-xl bg-slate-900/50 border border-white/5 hover:border-white/10 transition-colors">
                    <CheckCircle2 size={16} className="text-indigo-400 shrink-0 mt-0.5" />
                    <p className="text-xs text-gray-300 leading-relaxed font-sans">
                      {highlight}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right: The World Lore Codex Tabbed Explorer (Col 8-12) */}
          <div className="lg:col-span-5 flex flex-col h-full justify-between">
            <div className="rounded-2xl glass-panel border-white/5 overflow-hidden flex flex-col h-full">
              
              {/* Lore Explorer Title & Tabs Nav */}
              <div className="p-6 bg-slate-900/40 border-b border-white/5">
                <div className="flex items-center gap-2.5 mb-4">
                  <Globe2 size={18} className="text-cyan-400" />
                  <h3 className="text-sm font-hud font-bold text-gray-200 tracking-wider uppercase">
                    Interactive Lore Codex
                  </h3>
                </div>
                
                {/* Tabs selection buttons */}
                <div className="grid grid-cols-3 gap-1 bg-slate-950 p-1 rounded-lg border border-white/5 text-xs font-hud">
                  <button
                    onClick={() => setActiveTab('cosmos')}
                    className={`py-2 px-3 rounded transition-all cursor-pointer font-medium ${
                      activeTab === 'cosmos'
                        ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/20'
                        : 'text-gray-400 hover:text-gray-200'
                    }`}
                  >
                    The Cosmos
                  </button>
                  <button
                    onClick={() => setActiveTab('magic')}
                    className={`py-2 px-3 rounded transition-all cursor-pointer font-medium ${
                      activeTab === 'magic'
                        ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/20'
                        : 'text-gray-400 hover:text-gray-200'
                    }`}
                  >
                    Resonance
                  </button>
                  <button
                    onClick={() => setActiveTab('lore')}
                    className={`py-2 px-3 rounded transition-all cursor-pointer font-medium ${
                      activeTab === 'lore'
                        ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/20'
                        : 'text-gray-400 hover:text-gray-200'
                    }`}
                  >
                    Chronicles
                  </button>
                </div>
              </div>

              {/* Codex Core Content Area */}
              <div className="p-6 md:p-8 flex-grow flex flex-col justify-between">
                <div className="min-h-48">
                  {activeTab === 'cosmos' && (
                    <motion.div
                      key="cosmos"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-4"
                    >
                      <h4 className="text-sm font-hud font-bold text-cyan-400 flex items-center gap-1.5 uppercase">
                        <span className="w-1 h-1.5 bg-cyan-400 rounded-full" />
                        The Three Plateaus
                      </h4>
                      <p className="text-sm text-gray-300 leading-relaxed font-sans">
                        {novel.worldInfo.cosmos}
                      </p>
                      <div className="mt-4 p-3 rounded-lg bg-cyan-950/10 border border-cyan-500/10 flex items-center gap-2 text-xs text-cyan-300/90 font-hud">
                        <CalendarRange size={14} />
                        <span>Timeline Setting: {novel.timeline}</span>
                      </div>
                    </motion.div>
                  )}

                  {activeTab === 'magic' && (
                    <motion.div
                      key="magic"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-4"
                    >
                      <h4 className="text-sm font-hud font-bold text-violet-400 flex items-center gap-1.5 uppercase">
                        <span className="w-1 h-1.5 bg-violet-400 rounded-full" />
                        Chronos-Mana Resonance
                      </h4>
                      <p className="text-sm text-gray-300 leading-relaxed font-sans">
                        {novel.worldInfo.magicSystem}
                      </p>
                      <div className="mt-4 p-3 rounded-lg bg-violet-950/10 border border-violet-500/10 flex items-center gap-2 text-xs text-violet-300/90 font-hud">
                        <Flame size={14} />
                        <span>Risk Factor: Biological cellular decay & corruption</span>
                      </div>
                    </motion.div>
                  )}

                  {activeTab === 'lore' && (
                    <motion.div
                      key="lore"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-4"
                    >
                      <h4 className="text-sm font-hud font-bold text-amber-400 flex items-center gap-1.5 uppercase">
                        <span className="w-1 h-1.5 bg-amber-400 rounded-full" />
                        The Shattering Legacy
                      </h4>
                      <p className="text-sm text-gray-300 leading-relaxed font-sans">
                        {novel.worldInfo.loreText}
                      </p>
                      <div className="mt-4 p-3 rounded-lg bg-amber-950/10 border border-amber-500/10 flex items-center gap-2 text-xs text-amber-300/90 font-hud">
                        <ShieldCheck size={14} />
                        <span>Core Status: Heavily depleted & structurally unstable</span>
                      </div>
                    </motion.div>
                  )}
                </div>

                {/* Theme Highlights section footer */}
                <div className="mt-8 pt-6 border-t border-white/5 space-y-3.5">
                  <span className="text-[10px] text-gray-500 uppercase tracking-widest font-mono">Core Theme Focus</span>
                  <div className="flex flex-wrap gap-1.5">
                    {novel.mainThemes.map((theme) => (
                      <span key={theme} className="text-xs px-2.5 py-1 rounded bg-indigo-950/30 text-indigo-300 border border-indigo-500/10">
                        {theme}
                      </span>
                    ))}
                  </div>
                </div>

              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
