import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Twitter, BookOpen, Users, Compass, ExternalLink, Heart, Sparkles } from 'lucide-react';
import { Novel } from '../types';

interface AuthorSectionProps {
  novel: Novel;
}

export default function AuthorSection({ novel }: AuthorSectionProps) {
  const [isFollowing, setIsFollowing] = useState(false);
  const [followerCount, setFollowerCount] = useState(novel.authorFollowers);

  const handleFollowToggle = () => {
    if (isFollowing) {
      setFollowerCount(prev => prev - 1);
    } else {
      setFollowerCount(prev => prev + 1);
    }
    setIsFollowing(!isFollowing);
  };

  return (
    <section id="author" className="relative py-24 px-4 md:px-8 lg:px-12 bg-transparent overflow-hidden border-b border-white/5">
      {/* Absolute ambient lights behind author card */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-violet-950/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-4xl mx-auto relative z-10">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <span className="text-[11px] font-mono tracking-[0.25em] text-violet-400 uppercase font-semibold">
            06 / Architect of Worlds
          </span>
          <h2 className="text-3xl sm:text-4xl font-black font-display tracking-tight text-white">
            Meet the Author
          </h2>
          <div className="h-1 w-16 bg-violet-500 mx-auto rounded-full" />
        </div>

        {/* Detailed profile layout card */}
        <div className="p-8 md:p-12 rounded-3xl glass-panel border-white/5 flex flex-col md:flex-row gap-8 items-start md:items-center justify-between text-left relative overflow-hidden">
          
          {/* Subtle decoration inside card */}
          <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-indigo-500/5 rounded-full blur-2xl" />

          {/* Author Details block (Image and text details) */}
          <div className="flex flex-col sm:flex-row gap-6 items-start sm:items-center flex-grow max-w-2xl">
            {/* Visual Avatar frame */}
            <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-gradient-to-tr from-indigo-600 via-violet-600 to-cyan-500 p-1 shrink-0 shadow-[0_0_20px_rgba(99,102,241,0.25)] select-none">
              <div className="w-full h-full rounded-full bg-slate-950 flex items-center justify-center font-display font-black text-2xl text-gray-200">
                {novel.authorAvatar}
              </div>
            </div>

            <div className="space-y-3.5">
              <div className="space-y-1">
                <span className="text-[10px] font-mono text-violet-400 uppercase tracking-widest flex items-center gap-1">
                  <Sparkles size={11} className="text-violet-400" />
                  Primary Chronicler
                </span>
                <h3 className="text-2xl font-black font-display tracking-wide text-white">
                  {novel.author}
                </h3>
              </div>
              <p className="text-sm text-gray-300 leading-relaxed font-sans font-light">
                {novel.authorBio}
              </p>

              {/* Social networking anchors */}
              <div className="flex items-center gap-3 pt-2">
                <a 
                  href="#twitter"
                  onClick={(e) => { e.preventDefault(); alert('Following Valerius on Sector_X network...'); }}
                  className="p-2.5 rounded-xl bg-slate-950 border border-white/5 hover:border-violet-500/20 text-gray-400 hover:text-white transition-all"
                  title="Sector_X Link"
                >
                  <Twitter size={14} />
                </a>
                <a 
                  href="#site"
                  onClick={(e) => { e.preventDefault(); alert('Redirecting to scribe personal vault...'); }}
                  className="p-2.5 rounded-xl bg-slate-950 border border-white/5 hover:border-violet-500/20 text-gray-400 hover:text-white transition-all flex items-center gap-1.5 text-xs font-hud"
                  title="Official Chronology Vault"
                >
                  <Compass size={14} />
                  <span>Personal Portal</span>
                  <ExternalLink size={10} className="opacity-50" />
                </a>
              </div>
            </div>
          </div>

          {/* Right Section: Author engagement counters and CTA */}
          <div className="flex flex-col sm:flex-row md:flex-col items-stretch sm:items-center md:items-stretch gap-6 shrink-0 w-full md:w-auto border-t md:border-t-0 md:border-l border-white/5 pt-6 md:pt-0 md:pl-8">
            
            {/* Followers, Works stats */}
            <div className="grid grid-cols-2 gap-6 text-center md:text-left">
              <div>
                <p className="text-[10px] font-mono text-gray-500 uppercase tracking-wider flex items-center justify-center md:justify-start gap-1">
                  <BookOpen size={10} className="text-gray-600" />
                  Volumes
                </p>
                <p className="text-lg font-bold font-hud text-gray-100">{novel.authorWorksCount}</p>
              </div>
              <div>
                <p className="text-[10px] font-mono text-gray-500 uppercase tracking-wider flex items-center justify-center md:justify-start gap-1">
                  <Users size={10} className="text-gray-600" />
                  Followers
                </p>
                <p className="text-lg font-bold font-hud text-gray-100">{followerCount.toLocaleString()}</p>
              </div>
            </div>

            {/* Follow Button */}
            <button
              onClick={handleFollowToggle}
              className={`px-6 py-3 rounded-xl text-xs font-hud font-bold tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2 border ${
                isFollowing
                  ? 'bg-violet-500/10 text-violet-300 border-violet-500/30'
                  : 'bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white shadow-lg shadow-violet-500/10'
              }`}
            >
              <Heart size={13} className={isFollowing ? 'fill-violet-400 text-violet-400' : ''} />
              {isFollowing ? 'FOLLOWED' : 'FOLLOW SCRIBE'}
            </button>

          </div>

        </div>

      </div>
    </section>
  );
}
