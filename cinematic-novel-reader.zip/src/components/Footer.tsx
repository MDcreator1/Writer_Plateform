import React from 'react';
import { ArrowUp, Terminal, Shield, FileText } from 'lucide-react';

interface FooterProps {
  onScrollToTop: () => void;
}

export default function Footer({ onScrollToTop }: FooterProps) {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative py-12 px-4 md:px-8 bg-transparent border-t border-white/5 overflow-hidden text-center sm:text-left">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 relative z-10 text-gray-500 text-xs">
        
        {/* Left Column: Copyright & Terminal Indicator */}
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="flex items-center gap-1.5 text-indigo-400 font-hud font-bold">
            <Terminal size={14} />
            <span>AETHERIS NETWORK</span>
          </div>
          <span className="hidden sm:inline text-gray-700">|</span>
          <p className="font-sans font-light">
            © {currentYear} Valerius Vance. All dimensional chapters preserved.
          </p>
        </div>

        {/* Right Column: Links & Scroll to top button */}
        <div className="flex flex-col sm:flex-row items-center gap-6">
          <div className="flex items-center gap-4 font-hud">
            <a 
              href="#terms" 
              onClick={(e) => { e.preventDefault(); alert('Terms of dimensional usage: By reading, you agree to safeguard the core.'); }}
              className="hover:text-gray-300 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <FileText size={12} />
              Chronicle Terms
            </a>
            <a 
              href="#privacy" 
              onClick={(e) => { e.preventDefault(); alert('Privacy charter: Your biological lifespan metrics are private and never shared.'); }}
              className="hover:text-gray-300 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <Shield size={12} />
              Spire Privacy
            </a>
          </div>

          <button
            onClick={onScrollToTop}
            className="p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-white/5 hover:border-white/10 text-gray-400 hover:text-white transition-all cursor-pointer group flex items-center gap-1.5"
            title="Ascend to Upper Spires"
          >
            <span className="text-[10px] uppercase font-mono tracking-wider opacity-0 group-hover:opacity-100 transition-opacity">Ascend</span>
            <ArrowUp size={14} className="group-hover:-translate-y-0.5 transition-transform" />
          </button>
        </div>

      </div>
    </footer>
  );
}
