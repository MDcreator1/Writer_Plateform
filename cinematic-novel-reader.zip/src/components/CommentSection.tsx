import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, ThumbsUp, CornerDownRight, Send, Flame, Pin, ChevronDown } from 'lucide-react';
import { Comment, Reply } from '../types';

interface CommentSectionProps {
  initialComments: Comment[];
}

export default function CommentSection({ initialComments }: CommentSectionProps) {
  const [comments, setComments] = useState<Comment[]>(initialComments);
  const [newCommentText, setNewCommentText] = useState('');
  const [sortBy, setSortBy] = useState<'popular' | 'newest'>('popular');
  const [replyTargetId, setReplyTargetId] = useState<string | null>(null);
  const [newReplyText, setNewReplyText] = useState('');

  // Post primary comment
  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim()) return;

    const newComment: Comment = {
      id: `comm-user-${Date.now()}`,
      author: "Celestial_Novice",
      avatar: "CN",
      role: "VIP Reader",
      content: newCommentText.trim(),
      timestamp: "Just now",
      likes: 1,
      isPinned: false,
      isLikedByUser: true,
      replies: []
    };

    setComments(prev => [newComment, ...prev]);
    setNewCommentText('');
  };

  // Like a comment toggle
  const handleLikeComment = (commentId: string) => {
    setComments(prev => prev.map(c => {
      if (c.id === commentId) {
        const liked = !c.isLikedByUser;
        return {
          ...c,
          isLikedByUser: liked,
          likes: liked ? c.likes + 1 : c.likes - 1
        };
      }
      return c;
    }));
  };

  // Like a reply toggle
  const handleLikeReply = (commentId: string, replyId: string) => {
    setComments(prev => prev.map(c => {
      if (c.id === commentId) {
        return {
          ...c,
          replies: c.replies.map(r => {
            if (r.id === replyId) {
              const liked = !r.isLikedByUser;
              return {
                ...r,
                isLikedByUser: liked,
                likes: liked ? r.likes + 1 : r.likes - 1
              };
            }
            return r;
          })
        };
      }
      return c;
    }));
  };

  // Post a reply
  const handlePostReply = (commentId: string) => {
    if (!newReplyText.trim()) return;

    const newReply: Reply = {
      id: `rep-user-${Date.now()}`,
      author: "Celestial_Novice",
      avatar: "CN",
      content: newReplyText.trim(),
      timestamp: "Just now",
      likes: 0
    };

    setComments(prev => prev.map(c => {
      if (c.id === commentId) {
        return {
          ...c,
          replies: [...c.replies, newReply]
        };
      }
      return c;
    }));

    setNewReplyText('');
    setReplyTargetId(null);
  };

  // Sorted and prepared comments
  const processedComments = React.useMemo(() => {
    // Separate pinned and unpinned
    const pinned = comments.filter(c => c.isPinned);
    const unpinned = comments.filter(c => !c.isPinned);

    // Sort unpinned
    if (sortBy === 'popular') {
      unpinned.sort((a, b) => b.likes - a.likes);
    } else {
      // For simple mock timestamps, we put the user-added comments first, then others
      // Just sorting by ID since timestamp string is text
      unpinned.sort((a, b) => b.id.localeCompare(a.id));
    }

    return [...pinned, ...unpinned];
  }, [comments, sortBy]);

  return (
    <section id="comments" className="relative py-24 px-4 md:px-8 lg:px-12 bg-transparent border-t border-b border-white/5">
      <div className="absolute top-1/4 left-1/3 w-96 h-96 rounded-full bg-violet-950/10 blur-3xl pointer-events-none" />

      <div className="max-w-4xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-12">
          <div className="space-y-2 text-left">
            <span className="text-[11px] font-mono tracking-[0.25em] text-indigo-400 uppercase font-semibold">
              04 / Reader Sanctuary
            </span>
            <h2 className="text-2xl sm:text-3xl font-black font-display text-white">
              Scribe Discussion
            </h2>
          </div>

          {/* Sort Controls */}
          <div className="flex items-center gap-2 text-xs font-hud self-start sm:self-auto bg-slate-900/60 p-1 rounded-lg border border-white/5">
            <button
              onClick={() => setSortBy('popular')}
              className={`px-3 py-1.5 rounded transition-all cursor-pointer ${
                sortBy === 'popular' ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/10 font-semibold' : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              Popular Threads
            </button>
            <button
              onClick={() => setSortBy('newest')}
              className={`px-3 py-1.5 rounded transition-all cursor-pointer ${
                sortBy === 'newest' ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/10 font-semibold' : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              Chronological
            </button>
          </div>
        </div>

        {/* INPUT COMMENT FORM */}
        <form onSubmit={handlePostComment} className="p-4 rounded-2xl glass-panel border-indigo-500/10 mb-8 space-y-4">
          <div className="flex gap-4 items-start">
            <div className="w-10 h-10 rounded-full bg-cyan-950/40 border border-cyan-500/20 flex items-center justify-center font-bold text-xs text-cyan-400 shrink-0 select-none">
              CN
            </div>
            <div className="flex-grow">
              <textarea
                placeholder="Share your thoughts on the temporal thread or Kaelen's burden..."
                rows={3}
                value={newCommentText}
                onChange={(e) => setNewCommentText(e.target.value)}
                className="w-full bg-transparent outline-none text-sm text-gray-200 placeholder-gray-500 resize-none leading-relaxed"
              />
            </div>
          </div>
          <div className="flex items-center justify-between pt-3 border-t border-white/5">
            <span className="text-[10px] font-mono text-gray-500">Posting as <strong className="text-indigo-400">Celestial_Novice</strong></span>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl text-xs font-hud font-bold text-white bg-indigo-600 hover:bg-indigo-500 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Send size={12} />
              ENGRAVE COMMENT
            </button>
          </div>
        </form>

        {/* COMMENTS CONTAINER */}
        <div className="space-y-5 text-left">
          <AnimatePresence initial={false}>
            {processedComments.map((comment) => (
              <motion.div
                key={comment.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className={`p-5 rounded-2xl border transition-all ${
                  comment.isPinned 
                    ? 'bg-violet-950/10 border-violet-500/20 shadow-[0_4px_25px_-5px_rgba(139,92,246,0.1)]' 
                    : 'bg-slate-900/25 border-white/5 hover:border-white/10'
                }`}
              >
                {/* Header info */}
                <div className="flex items-start justify-between gap-4 mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-slate-950 border border-white/10 flex items-center justify-center font-bold text-xs text-gray-300">
                      {comment.avatar}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-hud font-bold text-gray-200">{comment.author}</span>
                        {comment.role && (
                          <span className={`text-[9px] font-mono uppercase px-1.5 py-0.2 rounded ${
                            comment.role === 'Author' 
                              ? 'bg-amber-500/15 text-amber-400 border border-amber-500/20' 
                              : comment.role === 'VIP Reader' 
                                ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                                : 'bg-slate-800 text-gray-400'
                          }`}>
                            {comment.role}
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] font-mono text-gray-500">{comment.timestamp}</span>
                    </div>
                  </div>

                  {comment.isPinned && (
                    <span className="flex items-center gap-1 text-[10px] font-mono text-violet-400 bg-violet-500/10 px-2 py-0.5 rounded-full border border-violet-500/25 uppercase tracking-wider">
                      <Pin size={10} className="fill-violet-400" />
                      Pinned by Author
                    </span>
                  )}
                </div>

                {/* Primary Comment Text */}
                <p className="text-sm text-gray-300 leading-relaxed font-sans font-light pl-13 mb-4">
                  {comment.content}
                </p>

                {/* Comment Actions bar */}
                <div className="flex items-center gap-4 pl-13 text-[11px] font-hud text-gray-500">
                  <button
                    onClick={() => handleLikeComment(comment.id)}
                    className={`flex items-center gap-1 hover:text-rose-400 cursor-pointer transition-colors ${
                      comment.isLikedByUser ? 'text-rose-400 font-semibold' : ''
                    }`}
                  >
                    <ThumbsUp size={11} className={comment.isLikedByUser ? 'fill-rose-400 text-rose-400' : ''} />
                    <span>{comment.likes} Likes</span>
                  </button>
                  <button
                    onClick={() => setReplyTargetId(replyTargetId === comment.id ? null : comment.id)}
                    className="flex items-center gap-1 hover:text-indigo-400 cursor-pointer transition-colors"
                  >
                    <MessageSquare size={11} />
                    <span>Reply</span>
                  </button>
                </div>

                {/* SUB-REPLY THREADS */}
                {comment.replies.length > 0 && (
                  <div className="mt-5 pl-13 space-y-4 border-l-2 border-indigo-500/10">
                    {comment.replies.map((reply) => (
                      <div key={reply.id} className="pt-2">
                        <div className="flex items-start gap-3">
                          <div className="w-8 h-8 rounded-full bg-slate-950 border border-white/5 flex items-center justify-center font-bold text-[10px] text-gray-400 shrink-0">
                            {reply.avatar}
                          </div>
                          <div className="space-y-1.5 flex-grow">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-hud font-bold text-gray-300">{reply.author}</span>
                              <span className="text-[9px] font-mono text-gray-500">{reply.timestamp}</span>
                            </div>
                            <p className="text-xs text-gray-400 leading-relaxed font-sans font-light">
                              {reply.content}
                            </p>
                            <button
                              onClick={() => handleLikeReply(comment.id, reply.id)}
                              className={`flex items-center gap-1 text-[10px] font-hud text-gray-500 hover:text-rose-400 cursor-pointer transition-colors ${
                                reply.isLikedByUser ? 'text-rose-400 font-semibold' : ''
                              }`}
                            >
                              <ThumbsUp size={10} className={reply.isLikedByUser ? 'fill-rose-400' : ''} />
                              <span>{reply.likes} Likes</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* LIVE REPLY INPUT BOX */}
                <AnimatePresence>
                  {replyTargetId === comment.id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-4 pl-13 overflow-hidden"
                    >
                      <div className="flex items-center gap-2 p-2 rounded-xl bg-slate-950 border border-white/5">
                        <CornerDownRight size={14} className="text-gray-500 ml-1" />
                        <input
                          type="text"
                          placeholder={`Reply to ${comment.author}...`}
                          value={newReplyText}
                          onChange={(e) => setNewReplyText(e.target.value)}
                          className="bg-transparent outline-none flex-grow text-xs text-gray-300 placeholder-gray-500 font-sans"
                        />
                        <button
                          onClick={() => handlePostReply(comment.id)}
                          className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-[10px] font-hud font-bold text-white transition-all cursor-pointer"
                        >
                          POST
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

              </motion.div>
            ))}
          </AnimatePresence>
        </div>

      </div>
    </section>
  );
}
