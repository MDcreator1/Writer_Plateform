import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { BookOpen, Star, Eye, ThumbsUp, Globe, Clock, ChevronDown, Award } from 'lucide-react';
import { Novel } from '../types';

interface HeroProps {
  novel: Novel;
  onStartReading: () => void;
  onViewChapters: () => void;
}

export default function Hero({ novel, onStartReading, onViewChapters }: HeroProps) {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      // Normalize to -0.5 to 0.5
      const x = (e.clientX / window.innerWidth) - 0.5;
      const y = (e.clientY / window.innerHeight) - 0.5;
      setMousePosition({ x, y });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center py-20 px-4 md:px-8 lg:px-12 overflow-hidden bg-transparent">
      {/* Cinematic Ambient Background Lights */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-violet-900/10 blur-3xl ambient-light-1 pointer-events-none" />
      <div className="absolute bottom-1/3 right-1/4 w-[450px] h-[450px] rounded-full bg-indigo-900/10 blur-3xl ambient-light-2 pointer-events-none" />
      <div className="absolute top-10 right-10 w-80 h-80 rounded-full bg-cyan-900/5 blur-3xl ambient-light-3 pointer-events-none" />

      {/* Floating particles mimicking floating ether */}
      <div className="absolute inset-0 pointer-events-none opacity-20">
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1.5 h-1.5 bg-indigo-400 rounded-full blur-[0.5px]"
            style={{
              top: `${15 + i * 5.5}%`,
              left: `${10 + (i * 7) % 80}%`,
            }}
            animate={{
              y: [0, -40, 0],
              x: [0, (i % 2 === 0 ? 15 : -15), 0],
              opacity: [0.1, 0.8, 0.1],
            }}
            transition={{
              duration: 8 + (i % 5) * 3,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        ))}
      </div>

      <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center relative z-10">
        
        {/* Left: Text and statistics (Col 1-7) */}
        <motion.div 
          className="lg:col-span-7 flex flex-col items-start text-left space-y-6"
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
          style={{
            transform: `translate3d(${mousePosition.x * 12}px, ${mousePosition.y * 12}px, 0)`
          }}
        >
          {/* Tagline / Award Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-panel text-xs font-hud font-medium text-cyan-400 border-cyan-500/10 tracking-wide uppercase">
            <Award size={14} className="text-cyan-400" />
            Interactive Story Universe
          </div>

          {/* Book Title */}
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black font-display text-transparent bg-clip-text bg-gradient-to-r from-gray-100 via-indigo-100 to-violet-300 tracking-tight leading-[1.1] text-glow">
            {novel.title}
          </h1>

          {/* Subtitle */}
          <p className="text-lg sm:text-xl font-sans text-indigo-200/80 font-light leading-relaxed max-w-2xl">
            {novel.subtitle}
          </p>

          {/* Author Tag */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-indigo-950 border border-indigo-500/20 flex items-center justify-center font-bold text-indigo-300 text-sm">
              {novel.authorAvatar}
            </div>
            <div>
              <p className="text-xs text-gray-400 tracking-wider uppercase font-mono">Written By</p>
              <p className="text-sm font-medium text-gray-200">{novel.author}</p>
            </div>
            <div className="h-6 w-px bg-gray-800 mx-2" />
            <span className="px-2.5 py-0.5 rounded text-xs bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 uppercase font-mono tracking-widest">
              {novel.status}
            </span>
          </div>

          {/* Key Stats Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 w-full py-4 px-5 rounded-2xl glass-panel border-white/5 font-hud text-sm">
            <div className="flex items-center gap-2.5">
              <Star className="text-amber-400 fill-amber-400/20" size={18} />
              <div>
                <p className="text-xs text-gray-500">Rating</p>
                <p className="font-semibold text-gray-200">{novel.rating} / 5</p>
              </div>
            </div>
            <div className="flex items-center gap-2.5">
              <Eye className="text-cyan-400" size={18} />
              <div>
                <p className="text-xs text-gray-500">Views</p>
                <p className="font-semibold text-gray-200">{novel.views}</p>
              </div>
            </div>
            <div className="flex items-center gap-2.5">
              <ThumbsUp className="text-indigo-400" size={18} />
              <div>
                <p className="text-xs text-gray-500">Likes</p>
                <p className="font-semibold text-gray-200">{novel.likes}</p>
              </div>
            </div>
            <div className="flex items-center gap-2.5">
              <Clock className="text-violet-400" size={18} />
              <div>
                <p className="text-xs text-gray-500">Duration</p>
                <p className="font-semibold text-gray-200">{novel.readingTime}</p>
              </div>
            </div>
          </div>

          {/* Short Description */}
          <p className="text-sm text-gray-400 leading-relaxed font-sans max-w-xl">
            {novel.description.slice(0, 200)}...
          </p>

          {/* Genre Badges */}
          <div className="flex flex-wrap gap-2 pt-2">
            {novel.genres.map((genre) => (
              <span key={genre} className="px-3 py-1 rounded-full text-xs bg-slate-900/80 border border-white/5 text-gray-300 font-hud tracking-wide hover:border-indigo-500/30 transition-all cursor-default">
                {genre}
              </span>
            ))}
          </div>

          {/* Action CTAs */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-4 w-full sm:w-auto">
            <button
              onClick={onStartReading}
              id="cta-start-reading"
              className="px-8 py-4 rounded-xl font-hud font-bold text-sm text-white bg-gradient-to-r from-indigo-600 via-violet-600 to-indigo-700 hover:from-indigo-500 hover:to-violet-500 shadow-[0_4px_25px_-5px_rgba(139,92,246,0.5)] active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer border border-white/10"
            >
              <BookOpen size={16} />
              START READING
            </button>
            <button
              onClick={onViewChapters}
              id="cta-view-chapters"
              className="px-8 py-4 rounded-xl font-hud font-semibold text-sm text-gray-300 bg-white/5 hover:bg-white/10 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer border border-white/5"
            >
              EXPLORE CHAPTERS
            </button>
          </div>
        </motion.div>

        {/* Right: Immersive 3D styled poster centerpiece (Col 8-12) */}
        <motion.div 
          className="lg:col-span-5 flex justify-center items-center py-4"
          initial={{ opacity: 0, scale: 0.9, rotateY: 15 }}
          animate={{ opacity: 1, scale: 1, rotateY: 0 }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
          style={{
            transform: `translate3d(${mousePosition.x * -20}px, ${mousePosition.y * -20}px, 0) rotateY(${mousePosition.x * 20}deg) rotateX(${mousePosition.y * -20}deg)`
          }}
        >
          {/* Interactive Cinematic Book Container */}
          <div className="relative group perspective-1000">
            {/* Soft Glowing Aura backing */}
            <div className="absolute -inset-4 rounded-[2rem] bg-gradient-to-r from-indigo-500/20 via-violet-500/10 to-cyan-500/20 blur-2xl group-hover:blur-3xl group-hover:opacity-100 opacity-85 transition-all duration-700" />
            
            {/* The Book Object */}
            <div className="relative w-72 sm:w-80 h-[440px] sm:h-[480px] rounded-2xl overflow-hidden shadow-[0_25px_50px_-12px_rgba(0,0,0,0.8)] border border-white/10 flex flex-col justify-between p-6 cursor-pointer select-none transition-all duration-500 transform group-hover:scale-[1.03] group-hover:border-indigo-400/30"
                 style={{ background: novel.coverImage }}>
              
              {/* Premium Foil reflection effect overlay */}
              <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-white/10 opacity-30 group-hover:opacity-50 transition-opacity duration-700 pointer-events-none" />
              
              {/* Top Banner details */}
              <div className="flex justify-between items-start relative z-10">
                <div className="text-[10px] font-mono uppercase tracking-widest text-indigo-300/80 bg-black/40 px-2.5 py-1 rounded-full border border-indigo-500/10">
                  Vol. I: Genesis
                </div>
                <Globe size={16} className="text-white/40 group-hover:text-cyan-400 transition-colors" />
              </div>

              {/* Center Decorative Core Ring */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-44 h-44 rounded-full border-2 border-dashed border-violet-500/10 flex items-center justify-center group-hover:rotate-45 transition-transform duration-10000 ease-linear">
                <div className="w-32 h-32 rounded-full border border-indigo-500/20 flex items-center justify-center">
                  <div className="w-20 h-20 rounded-full bg-indigo-500/5 flex items-center justify-center animate-pulse shadow-[inset_0_0_15px_rgba(99,102,241,0.2)]">
                    {/* Glow center */}
                    <div className="w-10 h-10 rounded-full bg-violet-500/10 border border-violet-400/40 blur-[0.5px]" />
                  </div>
                </div>
              </div>

              {/* Book Spine Simulation Accent Left */}
              <div className="absolute left-0 top-0 bottom-0 w-3 bg-black/25 border-r border-white/5 backdrop-blur-sm z-10" />

              {/* Title & Author Branding Bottom */}
              <div className="space-y-2 relative z-10">
                <p className="text-[10px] font-mono uppercase tracking-widest text-amber-400/90 flex items-center gap-1.5 gold-glow">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                  PREMIUM REVEAL
                </p>
                <h2 className="text-2xl sm:text-3xl font-black font-display text-white tracking-wide leading-tight group-hover:text-indigo-200 transition-colors">
                  Aetheris
                </h2>
                <div className="h-0.5 w-12 bg-indigo-500/50 group-hover:w-20 transition-all duration-500" />
                <p className="text-xs font-hud text-gray-400 tracking-wider uppercase pt-1">
                  {novel.author}
                </p>
              </div>

              {/* Holographic light streak */}
              <div className="absolute -inset-y-12 w-12 bg-white/15 blur-md skew-x-12 translate-x-[-200%] group-hover:translate-x-[400%] transition-transform duration-1000 ease-out pointer-events-none" />
            </div>

            {/* Behind Layer Shadow Accent */}
            <div className="absolute top-4 -right-2 -left-2 bottom-4 bg-slate-900/80 rounded-2xl -z-10 border border-white/5 shadow-2xl transform rotate-3 scale-95" />
          </div>
        </motion.div>

      </div>

      {/* Down Chevron Anchor indicator */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-1 cursor-pointer opacity-70 hover:opacity-100 transition-all" onClick={onViewChapters}>
        <span className="text-[10px] tracking-widest font-mono text-gray-500 uppercase">Scroll to Discover</span>
        <motion.div
          animate={{ y: [0, 5, 0] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
        >
          <ChevronDown size={18} className="text-indigo-400" />
        </motion.div>
      </div>
    </section>
  );
}
