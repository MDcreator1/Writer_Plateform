import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldAlert, Users, Compass, Eye, ShieldCheck, Heart, Sparkles, Brain, Flame } from 'lucide-react';
import { Character, Faction } from '../types';

interface CharacterSectionProps {
  characters: Character[];
  factions: Faction[];
}

export default function CharacterSection({ characters, factions }: CharacterSectionProps) {
  const [selectedCharId, setSelectedCharId] = useState<string>(characters[0].id);
  const [activeView, setActiveView] = useState<'characters' | 'factions'>('characters');

  const selectedCharacter = characters.find(c => c.id === selectedCharId) || characters[0];

  return (
    <section id="world" className="relative py-24 px-4 md:px-8 lg:px-12 bg-transparent overflow-hidden border-b border-white/5">
      {/* Background glow effects */}
      <div className="absolute top-1/4 right-1/4 w-96 h-96 rounded-full bg-indigo-950/15 blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 left-1/4 w-[400px] h-[400px] rounded-full bg-violet-950/15 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="space-y-4 text-left">
            <span className="text-[11px] font-mono tracking-[0.25em] text-violet-400 uppercase font-semibold">
              02 / Dramatis Personae
            </span>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black font-display tracking-tight text-white">
              Characters & Factions
            </h2>
            <div className="h-1 w-16 bg-violet-500 rounded-full" />
          </div>

          {/* Toggle buttons */}
          <div className="inline-flex bg-slate-900/60 p-1 rounded-xl border border-white/5 font-hud text-sm self-start md:self-auto">
            <button
              onClick={() => setActiveView('characters')}
              className={`px-5 py-2.5 rounded-lg font-medium transition-all cursor-pointer flex items-center gap-2 ${
                activeView === 'characters'
                  ? 'bg-violet-600/30 text-violet-200 border border-violet-500/20'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <Sparkles size={14} />
              Main Characters
            </button>
            <button
              onClick={() => setActiveView('factions')}
              className={`px-5 py-2.5 rounded-lg font-medium transition-all cursor-pointer flex items-center gap-2 ${
                activeView === 'factions'
                  ? 'bg-violet-600/30 text-violet-200 border border-violet-500/20'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <Users size={14} />
              Ruling Factions
            </button>
          </div>
        </div>

        {/* Dynamic Display Area */}
        <AnimatePresence mode="wait">
          {activeView === 'characters' ? (
            <motion.div
              key="characters-view"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch"
            >
              {/* Left Column: Character Selection Cards (Col 1-5) */}
              <div className="lg:col-span-5 flex flex-col gap-4">
                <span className="text-xs text-gray-500 font-mono uppercase tracking-wider pl-1">
                  Select a Presence:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-3.5">
                  {characters.map((char) => {
                    const isSelected = char.id === selectedCharId;
                    return (
                      <div
                        key={char.id}
                        onClick={() => setSelectedCharId(char.id)}
                        className={`p-4 rounded-xl cursor-pointer text-left transition-all flex items-center justify-between border ${
                          isSelected
                            ? 'bg-violet-950/20 border-violet-500/50 shadow-[0_4px_20px_-5px_rgba(139,92,246,0.25)]'
                            : 'bg-slate-900/40 border-white/5 hover:bg-slate-900/80 hover:border-white/10'
                        }`}
                      >
                        <div className="flex items-center gap-4">
                          {/* Colored Glowing Avatar Indicator */}
                          <div 
                            className="w-11 h-11 rounded-full border border-white/10 flex items-center justify-center font-bold font-hud text-sm relative overflow-hidden"
                            style={{ backgroundColor: isSelected ? 'rgba(139, 92, 246, 0.15)' : 'rgba(255,255,255,0.03)' }}
                          >
                            <span className={isSelected ? 'text-violet-300' : 'text-gray-400'}>
                              {char.avatar}
                            </span>
                            {isSelected && (
                              <div className="absolute inset-0 bg-violet-400/10 blur-[2px]" />
                            )}
                          </div>
                          <div>
                            <h4 className={`text-base font-hud font-bold tracking-tight transition-colors ${
                              isSelected ? 'text-violet-300' : 'text-gray-200'
                            }`}>
                              {char.name}
                            </h4>
                            <p className="text-xs text-gray-400 font-sans mt-0.5">
                              {char.role}
                            </p>
                          </div>
                        </div>

                        {/* Side pill */}
                        <div className={`text-[10px] font-mono uppercase px-2.5 py-0.5 rounded-full border ${
                          isSelected 
                            ? 'bg-violet-500/10 text-violet-300 border-violet-500/20' 
                            : 'bg-black/30 text-gray-500 border-white/5'
                        }`}>
                          {char.affinity.split('-')[0]}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Right Column: Elaborate Character Detail (Col 6-12) */}
              <div className="lg:col-span-7 flex">
                <div 
                  className="rounded-2xl w-full p-8 md:p-10 border border-white/5 relative overflow-hidden flex flex-col justify-between"
                  style={{ 
                    background: `radial-gradient(circle at top right, ${selectedCharacter.cardImage}, rgba(10, 10, 20, 0.85) 55%)` 
                  }}
                >
                  {/* Absolute backdrop shadow design */}
                  <div className="absolute top-1/4 right-0 w-64 h-64 bg-violet-500/5 rounded-full blur-3xl pointer-events-none" />

                  {/* Top Character Details */}
                  <div className="space-y-6 relative z-10">
                    <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/5 pb-5">
                      <div className="space-y-1">
                        <span className="text-xs text-violet-400 font-mono tracking-widest uppercase">
                          {selectedCharacter.role}
                        </span>
                        <h3 className="text-3xl font-black font-display tracking-wide text-white">
                          {selectedCharacter.name}
                        </h3>
                      </div>
                      <div className="px-4 py-2 rounded-xl bg-slate-900/80 border border-violet-500/10 flex flex-col items-end">
                        <span className="text-[10px] text-gray-500 font-mono uppercase">Affinity Element</span>
                        <span className="text-sm font-semibold text-violet-300 font-hud">
                          {selectedCharacter.affinity}
                        </span>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h4 className="text-xs text-gray-400 font-mono uppercase tracking-wider">Biography & Directives</h4>
                      <p className="text-sm text-gray-300 leading-relaxed font-sans font-light">
                        {selectedCharacter.description}
                      </p>
                    </div>

                    {/* Faction Alignment Details */}
                    <div className="p-4 rounded-xl bg-black/40 border border-white/5 flex items-center gap-3.5">
                      <Compass size={18} className="text-violet-400 shrink-0" />
                      <div>
                        <p className="text-[10px] font-mono text-gray-500 uppercase">Current Alignment</p>
                        <p className="text-sm font-hud font-semibold text-gray-300">{selectedCharacter.faction}</p>
                      </div>
                    </div>
                  </div>

                  {/* Character Stats HUD Metrics (Power levels) */}
                  <div className="mt-8 pt-6 border-t border-white/5 space-y-4 relative z-10">
                    <h4 className="text-xs text-gray-400 font-mono uppercase tracking-wider flex items-center gap-1.5">
                      <Brain size={14} className="text-violet-400" />
                      Core Capabilities HUD
                    </h4>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                      {/* Stat 1: Power */}
                      <div className="space-y-1.5">
                        <div className="flex justify-between text-xs font-hud text-gray-400">
                          <span>Physical Power</span>
                          <span className="text-violet-300 font-mono font-medium">{selectedCharacter.stats.power}%</span>
                        </div>
                        <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden">
                          <motion.div 
                            className="h-full bg-gradient-to-r from-violet-600 to-indigo-500 rounded-full"
                            initial={{ width: 0 }}
                            animate={{ width: `${selectedCharacter.stats.power}%` }}
                            transition={{ duration: 0.8, ease: "easeOut" }}
                          />
                        </div>
                      </div>

                      {/* Stat 2: Intellect */}
                      <div className="space-y-1.5">
                        <div className="flex justify-between text-xs font-hud text-gray-400">
                          <span>Intellect / Strategy</span>
                          <span className="text-cyan-300 font-mono font-medium">{selectedCharacter.stats.intellect}%</span>
                        </div>
                        <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden">
                          <motion.div 
                            className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full"
                            initial={{ width: 0 }}
                            animate={{ width: `${selectedCharacter.stats.intellect}%` }}
                            transition={{ duration: 0.8, ease: "easeOut" }}
                          />
                        </div>
                      </div>

                      {/* Stat 3: Resonance */}
                      <div className="space-y-1.5">
                        <div className="flex justify-between text-xs font-hud text-gray-400">
                          <span>Mana Resonance</span>
                          <span className="text-fuchsia-300 font-mono font-medium">{selectedCharacter.stats.resonance}%</span>
                        </div>
                        <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden">
                          <motion.div 
                            className="h-full bg-gradient-to-r from-fuchsia-500 to-violet-500 rounded-full"
                            initial={{ width: 0 }}
                            animate={{ width: `${selectedCharacter.stats.resonance}%` }}
                            transition={{ duration: 0.8, ease: "easeOut" }}
                          />
                        </div>
                      </div>

                    </div>
                  </div>

                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="factions-view"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              className="grid grid-cols-1 md:grid-cols-3 gap-6"
            >
              {factions.map((faction) => (
                <div key={faction.id} className="p-6 rounded-2xl glass-panel border-white/5 hover:border-violet-500/20 hover:bg-slate-900/60 transition-all duration-300 flex flex-col justify-between text-left group">
                  <div className="space-y-4">
                    {/* Sigil Badge */}
                    <div className="w-10 h-10 rounded-xl bg-violet-950/20 border border-violet-500/20 text-violet-400 flex items-center justify-center group-hover:scale-105 transition-transform">
                      <Users size={18} />
                    </div>
                    <div className="space-y-1">
                      <span className="text-[10px] font-mono text-violet-400 uppercase tracking-widest">{faction.region}</span>
                      <h3 className="text-xl font-hud font-bold text-gray-100">{faction.name}</h3>
                    </div>
                    <p className="text-xs text-gray-400 font-sans leading-relaxed">
                      {faction.description}
                    </p>
                  </div>
                  
                  {/* Faction metadata card footer */}
                  <div className="mt-6 pt-4 border-t border-white/5 flex flex-col gap-1 text-[11px] font-mono text-gray-500">
                    <span>Emblem Sigil:</span>
                    <span className="text-gray-300 font-hud">{faction.sigil}</span>
                  </div>
                </div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}
