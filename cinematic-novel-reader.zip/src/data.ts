import { Novel, Character, Faction, Chapter, Comment, Recommendation } from './types';

export const novelData: Novel = {
  title: "Aetheris: Shadow of the Core",
  subtitle: "In the neon-drenched spires of Aethelgard, time is a currency, and the core is bleeding.",
  coverImage: "linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #311042 100%)",
  author: "Valerius Vance",
  authorBio: "Valerius Vance is an award-winning speculative fiction writer who blends cosmic fantasy, high-technology lore, and deep psychological character arcs. Winner of the Codex Nebula Prize.",
  authorAvatar: "VV",
  authorWorksCount: 7,
  authorFollowers: 14205,
  rating: 4.93,
  views: "2.4M",
  likes: "384K",
  language: "English (US)",
  status: "Ongoing",
  totalChapters: 48,
  readingTime: "12 hours",
  description: "A dark cyberpunk-fantasy epic. Within the high-altitude metropolis of Aethelgard, citizens trade their lifespans for synthetic mana. When a subterranean technician uncovers the 'Shadow Core'—an ancient, living engine of void-energy—he triggers a cascade that threatens to collapse the physical fabric of temporal reality. He must ally with an exiled royal rebel and a time-weaving shadow assassin to stop the Archons from sacrificing the city to feed the Core.",
  genres: ["Sci-Fi", "Dark Fantasy", "Cyberpunk", "Space Opera", "Psychological"],
  tags: ["Anti-Hero", "Time Control", "Steampunk Tech", "Ancient Prophecy", "Rich Worldbuilding"],
  synopsis: "Ten thousand meters above the poisoned clouds of the surface, Aethelgard floats as a testament to humanity's absolute defiance. Built around the perpetual light-wells, the city runs entirely on Lumina, a fluid energy refined from the celestial ether. But behind the shimmering crystal facades lies a grim economic truth: Lumina is refined by condensing the biological lifespans of the lower-tier labor force. When Kaelen Vex, a Core technician of the subterranean Sector 9, is tasked with fixing a sudden pressure drop in the central conduit, he discovers something that shouldn't exist. Not a leaking valve, but an absolute localized tear in space-time—a pulsing, sentient obsidian heart known only as the Shadow Core. Drawn into its gravity, Kaelen is branded with its void-resonance. Now hunted by the pristine Archons of the Upper Spires, Kaelen must navigate a labyrinth of syndicate wars, celestial politics, and the unraveling lines of his own mind, before the core claims its final tribute.",
  timeline: "Year 842 of the Floating Epoch (Post-Cataclysm Era)",
  worldInfo: {
    cosmos: "The world consists of three tiers of floating plateaus: The Upper Elysium (home of the high-wealth Archons), The Mid-Spires (commercial and research hubs), and The Under-Sectors (smog-covered industrial roots). Below lies the Void-Ocean, a misty expanse of dead land where nothing organic survives.",
    magicSystem: "Chronos-Mana Resonance. Humans can inject liquefied ether directly into their neuro-conduits to manipulate localized physical constants (gravity, heat, inertia). However, overcharging corrupts the neural pathways, causing 'Core-fever' or complete spatial phase-out.",
    loreText: "The Shattering occurred six centuries ago, when the ancient planetary core collapsed. The remaining survivors harnessed gravity-anchors and celestial magnets to lift chunks of the continental shelf into the skies, forming the Seven Skyland Alliances."
  },
  mainThemes: ["Sacrifice vs. Progress", "The Commodification of Time", "Techno-Feudal Tyranny", "Cognitive Fragmentation"],
  storyHighlights: [
    "Winner of the 2026 Interactive Fiction Grand Prize",
    "Stunning high-contrast worldbuilding blending mechanical depth with celestial awe",
    "Non-linear lore elements revealed through sensory annotations",
    "Deeply complex characters with conflicting moral compasses"
  ]
};

export const charactersData: Character[] = [
  {
    id: "char-1",
    name: "Kaelen Vex",
    role: "Protagonist",
    faction: "The Under-Sector Syndicate",
    affinity: "Void-Resonance",
    avatar: "KV",
    cardImage: "rgba(139, 92, 246, 0.15)", // Indigo glow tint
    description: "A pragmatic Core technician whose exposure to the Shadow Core granted him the terrifying ability to dissolve momentum and phase through physical boundaries, at the cost of his own cellular stability.",
    stats: {
      power: 84,
      intellect: 92,
      resonance: 97
    }
  },
  {
    id: "char-2",
    name: "Archon Selene",
    role: "Antagonist",
    faction: "Aethelgard High Council",
    affinity: "Gravity Nullifier",
    avatar: "AS",
    cardImage: "rgba(239, 68, 68, 0.15)", // Crimson glow tint
    description: "The absolute ruler of the Elysium Spire. Blinded by the conviction that Aethelgard's survival requires infinite power, she intends to trigger a total Core Harvest, erasing the lower sectors to elevate her tier into the star-ways.",
    stats: {
      power: 98,
      intellect: 95,
      resonance: 89
    }
  },
  {
    id: "char-3",
    name: "Lyra Thorn",
    role: "Companion",
    faction: "The Astral Guild of Exiles",
    affinity: "Chronos-Weaver",
    avatar: "LT",
    cardImage: "rgba(6, 182, 212, 0.15)", // Cyan glow tint
    description: "An aristocratic rebel and daughter of a disgraced council lord. Lyra can stitch localized temporal anomalies, allowing her to rewind private events by exactly four seconds, a lethal gift in duel mechanics.",
    stats: {
      power: 76,
      intellect: 88,
      resonance: 94
    }
  },
  {
    id: "char-4",
    name: "Maelis Karr",
    role: "Deuteragonist",
    faction: "The Iron Clad Guard",
    affinity: "Kinetic Shear",
    avatar: "MK",
    cardImage: "rgba(234, 179, 8, 0.15)", // Amber glow tint
    description: "A battle-hardened commander who chose exile over a mass purge order. Maelis commands heavy cybernetic plating and can convert incoming physical kinetic force directly into explosive close-quarters heat.",
    stats: {
      power: 95,
      intellect: 79,
      resonance: 68
    }
  }
];

export const factionsData: Faction[] = [
  {
    id: "fac-1",
    name: "The High Council",
    description: "The elite caste who control the flow of Lumina and govern the city from their gilded gardens in Upper Elysium. They maintain power through complete surveillance and the elite Praetorian Guard.",
    region: "Tier 1: Upper Elysium",
    sigil: "Gold Ring with a Crown of Light"
  },
  {
    id: "fac-2",
    name: "The Under-Sector Syndicate",
    description: "A loose coalition of labor cartels, shadow merchants, and rogue engineers who run the industrial underground. They survive by smuggling black-market mana and maintaining the auxiliary engines.",
    region: "Tier 3: The Under-Sectors",
    sigil: "An inverted gear enclosing a closed eye"
  },
  {
    id: "fac-3",
    name: "The Astral Seekers",
    description: "An outlawed monastic order of scholars who believe the floating sky-islands are slowly decaying and that humanity's only salvation lies in reconnecting with the ruined terrestrial surface below.",
    region: "The Edge-Outposts",
    sigil: "A shattered stellar compass"
  }
];

export const chaptersData: Chapter[] = [
  {
    id: "chap-1",
    number: 1,
    title: "The Chronos Weaver",
    volumeId: 1,
    volumeName: "Volume 1: The Dark Genesis",
    readingTime: "12 min",
    publishDate: "June 12, 2026",
    likes: 1248,
    commentsCount: 84,
    isLocked: false,
    summary: "Kaelen Vex descends into the abyssal maintenance shafts of Sector 9, discovering a tear in the engine that hums with forbidden void-energies.",
    content: [
      "The descent into Sector 9 was always marked by the taste of copper and cold grease. In the maintenance cage of Elevator 4, Kaelen Vex adjusted the straps of his pressure mask, listening to the rhythmic, complaining shriek of ancient steel cables. Ten thousand meters above them, the aristocrats of Elysium bathed in artificial starlight, drinking wine cooled by vaporized gravity. Down here, the only light was the angry, periodic strobe of emergency halogen lamps.",
      "“Don't stare at the light-wells too long,” Lyra's voice cracked through the static of his headset, a low, melodic warning from the surface terminal. “The Council increased the Lumina throughput this morning. The radiation is spiking in the lower conduits.”",
      "Kaelen grimaced, tightening his grip on his heavy plasma spanner. “If the conduits blow, we won't have to worry about radiation. The entire plateau will drop like a lead weight into the cloud-graves. How's the pressure reading on your end?”",
      "There was a pause. The hum of heavy diagnostics filled the line, accompanied by the distant, thunderous vibration of the secondary turbines. “Unstable,” Lyra replied, her tone sharpening. “The primary containment vault in Sector 9 is registering a negative density. Kaelen... that shouldn't be mathematically possible. A negative pressure means something down there is sucking light out of the grid.”",
      "The elevator cage shuddered to a halt, the heavy iron gates clanging open with an echo that sounded like a gunshot in the dark. A thick, violet-tinted smog rolled across the platform, smelling faintly of burnt sugar and ozone. Kaelen stepped out onto the iron catwalk. The air was unnaturally cold, freezing the moisture on his visor into intricate, crystalline fractals.",
      "He activated his shoulder lamp. The beam of light stabbed through the heavy mist, illuminating massive hydraulic pipes that pulsed with liquid Lumina—a brilliant, sky-blue fluid that looked like liquid starlight. But as Kaelen approached the central junction box, he noticed the blue pulses were becoming irregular. They stuttered, turning a bruised, deep-purple hue before disappearing into the main valve.",
      "“I'm at the junction,” Kaelen muttered, stepping carefully over frozen puddles of condensed ether. He reached out with his diagnostics probe, touching the metallic shell of the main conduit. Instantly, a heavy, resonant vibration surged up his arm, bypasses his suit's insulation. It wasn't a mechanical frequency. It felt like a low, rhythmic heartbeat—slow, ancient, and hungry.",
      "The plasma display on his handheld scanner suddenly flickered, its green numbers spinning wildly before freezing into a single, nonsensical sequence of glyphs. Kaelen's heart hammered against his ribs. He wiped his visor, leaning closer to the primary chamber. There, behind the thick quartz observation window, there was no Lumina. There was only a void—a localized sphere of absolute pitch-black space that seemed to pull the light from his shoulder lamp into its orbit.",
      "“Lyra,” Kaelen whispered, his voice trembling under his mask. “There's no leak. There's a rip in the casing. And there's... something inside. It's looking at me.”",
      "Before Lyra could answer, the quartz window spider-webbed with fine, hair-like cracks. A silent explosion of absolute cold threw Kaelen backward. He hit the steel grating, his spanner clattering into the dark abyss below. As the violet smog rushed in to fill the vacuum, Kaelen watched in horror as a single, obsidian tendril of void energy reached out from the cracked vault, coiling slowly around his right wrist. It didn't burn. It did something far worse—it made him feel, for a fleeting microsecond, like he had existed forever."
    ]
  },
  {
    id: "chap-2",
    number: 2,
    title: "Echoes of the Shattered Core",
    volumeId: 1,
    volumeName: "Volume 1: The Dark Genesis",
    readingTime: "15 min",
    publishDate: "June 18, 2026",
    likes: 1542,
    commentsCount: 112,
    isLocked: false,
    summary: "As the branding on his wrist begins to burn, Kaelen is hunted through the smelting wards by the Archon's elite kinetic enforcers.",
    content: [
      "The pain didn't begin until the light returned. Kaelen lay on the cold catwalk, his right arm outstretched, trembling under the dark energy that had branded itself into his skin. Where the obsidian tendril had touched him, a complex, glowing geometric pattern of violet veins now pulsed just beneath his epidermis, spiraling from his wrist up to his shoulder like a celestial map.",
      "“Kaelen! Answer me! The telemetry just spiked to lethal levels!” Lyra’s voice was screaming in his ear, but it sounded distant, muffled as if she were shouting from underwater. “Get out of there! A squad of Praetorian Enforcers just boarded the express lift from Elysium. They tracked the spatial disruption!”",
      "Kaelen pushed himself up, his muscles aching with an unnatural fatigue. He looked at his hand. When he clenched his fist, the air around his fingers seemed to blur, leaving faint trails of static shadow in the air. He didn't have time to understand it. The far end of the catwalk hissed as a high-frequency pneumatic door slide open.",
      "Three figures stepped out of the steam. They wore the polished, bone-white ceramic armor of the Archon's guard, their faceplates completely featureless mirrors. Each carried a kinetic lance that crackled with condensed gravity fields. The leader raised his weapon, the barrel glowing with an icy blue light.",
      "“Subject 409-Vex,” the guard’s voice was synthesized, completely devoid of emotion. “You have been exposed to unregistered high-tier materials. Stand down and prepare for genetic quarantine.”",
      "“Genetic quarantine means the smelting vats, Kaelen!” Lyra hissed. “Run!”",
      "Kaelen didn't hesitate. He turned and sprinted down the opposite direction of the catwalk. Behind him, a sharp hum echoed, followed by a concussive blast of air. The metal grid beneath his feet buckled as a compressed gravity slug shattered the steel, sending a shower of sparks into the dark. The kinetic force threw him off balance, his body tilting over the railing.",
      "He grabbed the handrail with his right hand. The moment his branded skin touched the metal, the violent geometric patterns flared. Instead of falling, Kaelen felt a strange sensation of absolute zero weight. His momentum ceased. He hovered for a fraction of a second, completely suspended in mid-air, before his body drifted downward, landing softly on a massive moving conveyor belt fifty feet below like a falling leaf.",
      "The belt was carrying glowing heaps of raw ether-ore toward the great smelting furnaces of Sector 9. The air here was a roaring furnace of white heat, the roar of the massive plasma arcs drowning out all other sounds. Kaelen looked up. The three Praetorians were already jumping down, their thrusters slowing their descent, landing on the parallel platforms with terrifying precision.",
      "“He's manipulating mass!” one of the guards shouted, his voice barely audible over the roaring furnaces. “Deploy the dampening fields!”",
      "Kaelen scrambled to his feet on the shifting ore. He could feel the branding on his wrist heat up, reacting to the proximity of the immense power grid. He needed to escape the smelting ward, but the exits were blocked by automated security grates. With the guards closing in, their gravity lances humming, Kaelen closed his eyes and reached out toward the heavy iron gate blocking the conveyor's end. He didn't know what he was doing—he only knew he didn't want to burn."
    ]
  },
  {
    id: "chap-3",
    number: 3,
    title: "Archon's Verdict",
    volumeId: 1,
    volumeName: "Volume 1: The Dark Genesis",
    readingTime: "14 min",
    publishDate: "June 24, 2026",
    likes: 1890,
    commentsCount: 145,
    isLocked: true,
    summary: "Brought before Archon Selene in the floating glass palace of Elysium, Kaelen learns the horrifying truth about the city's infinite longevity.",
    content: [
      "This chapter is currently locked in the preview version of the experience. To access the high-altitude glass spires of Elysium, join our Premium Circle or unlock this chapter using Core Mana Fragments.",
      "In the full release, Kaelen Vex faces the absolute scale of the High Council's betrayal. He discovers that the lifespans harvested from the lower tier are not merely running the city—they are being fed to a dormant entity inside the planet's core to keep gravity from reclaiming the Skylands.",
      "“Your life is a drop in an ocean of survival,” Archon Selene tells Kaelen, her eyes glowing with the cold, unforgiving light of a thousand stolen years. “Would you drown the world to save your single droplet?”"
    ]
  },
  {
    id: "chap-4",
    number: 4,
    title: "Resonance Cascade",
    volumeId: 1,
    volumeName: "Volume 1: The Dark Genesis",
    readingTime: "18 min",
    publishDate: "June 30, 2026",
    likes: 2102,
    commentsCount: 198,
    isLocked: true,
    summary: "Lyra and Kaelen trigger a localized temporal loop inside the treasury vault, setting off a race against the elite gravity sentinels.",
    content: [
      "This chapter is locked in the preview build.",
      "Discover the breathtaking synergy of Chronos-weaving and Void-resonance. In this high-stakes heist chapter, Lyra and Kaelen attempt to steal the central containment matrix before the Upper Spires initiate the Great Harvest.",
      "Unlock now to experience the dual-perspective timeline narrative!"
    ]
  }
];

export const commentsData: Comment[] = [
  {
    id: "comm-1",
    author: "Valerius Vance",
    avatar: "VV",
    role: "Author",
    content: "Welcome to the interactive preview of Aetheris! This novel is my love letter to dark fantasy, cyberpunk mechanical logic, and complex human trauma. I'll be hanging out in the comments to talk about the lore, the physics of Lumina, and Kaelen's descent. Chapter 3 goes live next week!",
    timestamp: "2 days ago",
    likes: 842,
    isPinned: true,
    replies: [
      {
        id: "rep-1-1",
        author: "NeoWeaver_4",
        avatar: "NW",
        content: "Oh my god, Valerius! The description of the void coiling around Kaelen's wrist was absolutely chilling. Is the 'void' connected to the cataclysm that shattered the terrestrial surface 600 years ago?",
        timestamp: "1 day ago",
        likes: 145
      },
      {
        id: "rep-1-2",
        author: "Valerius Vance",
        avatar: "VV",
        content: "You're asking the right questions, Neo. The Shattering wasn't a natural disaster. It was a failed extraction experiment. The ancient Core didn't collapse; it was mined.",
        timestamp: "18 hours ago",
        likes: 230
      }
    ]
  },
  {
    id: "comm-2",
    author: "Elena_Valkyrie",
    avatar: "EV",
    role: "VIP Reader",
    content: "The cinematic pacing of Chapter 2 is incredible! The transition from heavy gravity fields to Kaelen realizing he can dissolve momentum feels like something straight out of a premium film. I literally held my breath during the smelting furnace leap!",
    timestamp: "1 day ago",
    likes: 312,
    isPinned: false,
    replies: []
  },
  {
    id: "comm-3",
    author: "ChronosKeeper",
    avatar: "CK",
    role: "Reader",
    content: "I love the magic system. The idea of exchanging biological lifespan as a currency for mana is such a brilliant, dark metaphor for industrial capitalism. The Archons are terrifying because their longevity is literally fueled by the youth of the lower sectors.",
    timestamp: "3 days ago",
    likes: 198,
    isPinned: false,
    replies: [
      {
        id: "rep-3-1",
        author: "Scribe_Mina",
        avatar: "SM",
        content: "Exactly! It makes the conflict feel so much more meaningful than just good vs. evil. Selene genuinely believes she is preserving humanity.",
        timestamp: "2 days ago",
        likes: 54
      }
    ]
  },
  {
    id: "comm-4",
    author: "VoidWatcher",
    avatar: "VW",
    role: "Reader",
    content: "Can we talk about Lyra? Her ability to stitch time by exactly 4 seconds is such a smart, limited superpower. It prevents her from being overpowered but makes close-quarters combat so tense. Phenomenal design, Vance!",
    timestamp: "4 days ago",
    likes: 125,
    isPinned: false,
    replies: []
  }
];

export const recommendationsData: Recommendation[] = [
  {
    id: "rec-1",
    title: "Chronicles of Neon",
    rating: 4.88,
    coverImage: "linear-gradient(135deg, #090d16 0%, #06b6d4 100%)", // Cyan gradient
    genres: ["Cyberpunk", "AI Thriller", "Dystopian"],
    shortDescription: "In a city run by an omniscient synthetic consciousness, a data courier discovers a rogue file containing the memories of the AI's dead human creator.",
    author: "Cassandra Blake",
    views: "1.8M"
  },
  {
    id: "rec-2",
    title: "Echoes of the Void",
    rating: 4.91,
    coverImage: "linear-gradient(135deg, #0f051d 0%, #ec4899 100%)", // Pink/Purple gradient
    genres: ["Cosmic Horror", "Space Opera", "Magic Tech"],
    shortDescription: "An exploration vessel at the edge of the galaxy receives a distress beacon from a legendary starship that vanished into a black hole three centuries ago.",
    author: "Alistair Thorne",
    views: "980K"
  },
  {
    id: "rec-3",
    title: "Solaria: The Solar Crown",
    rating: 4.79,
    coverImage: "linear-gradient(135deg, #1e1b4b 0%, #f59e0b 100%)", // Amber/Indigo gradient
    genres: ["High Fantasy", "Empire Politics", "Celestial"],
    shortDescription: "When the undying Solar Emperor is assassinated, his seven children must compete in a lethal trial of light-weaving to claim the burning throne.",
    author: "Livia Vance-Gale",
    views: "3.1M"
  }
];
