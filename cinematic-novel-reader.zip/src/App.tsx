import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Terminal, Sparkles, X, Lock, Flame, ShieldCheck, 
  BookOpen, Compass, Award, AlertCircle 
} from 'lucide-react';

import Hero from './components/Hero';
import StoryOverview from './components/StoryOverview';
import CharacterSection from './components/CharacterSection';
import ChapterBrowser from './components/ChapterBrowser';
import ReaderSection from './components/ReaderSection';
import CommentSection from './components/CommentSection';
import Recommendations from './components/Recommendations';
import AuthorSection from './components/AuthorSection';
import Footer from './components/Footer';

import { 
  novelData, 
  charactersData, 
  factionsData, 
  chaptersData as initialChaptersData, 
  commentsData, 
  recommendationsData 
} from './data';
import { Chapter } from './types';

export default function App() {
  const [chapters, setChapters] = useState<Chapter[]>(initialChaptersData);
  const [activeChapterId, setActiveChapterId] = useState<string>('chap-1');
  const [completedChapterIds, setCompletedChapterIds] = useState<string[]>(['chap-1']);
  const [bookmarkedChapterIds, setBookmarkedChapterIds] = useState<string[]>([]);
  
  // Custom interactive notification state
  const [notification, setNotification] = useState<string | null>(null);

  // Locked chapter premium modal triggers
  const [showUnlockModal, setShowUnlockModal] = useState(false);
  const [selectedLockChapter, setSelectedLockChapter] = useState<{ title: string; number: number; id: string } | null>(null);

  // Active chapter finder
  const activeChapter = chapters.find(c => c.id === activeChapterId) || chapters[0];

  // Helper to trigger notifications
  const triggerNotification = (message: string) => {
    setNotification(message);
    setTimeout(() => {
      setNotification(null);
    }, 4500);
  };

  // Scroll smoothly to specific section
  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  // Handle CTA trigger from Hero
  const handleStartReading = () => {
    setActiveChapterId('chap-1');
    triggerNotification("Temporal gateway connected. Reading Volume 1.");
    scrollToSection('reader');
  };

  // Handle Toggle Bookmark callback
  const handleToggleBookmark = (chapterId: string) => {
    const chapter = chapters.find(c => c.id === chapterId);
    if (!chapter) return;

    if (bookmarkedChapterIds.includes(chapterId)) {
      setBookmarkedChapterIds(prev => prev.filter(id => id !== chapterId));
      triggerNotification(`Removed bookmark: Ch. ${chapter.number}`);
    } else {
      setBookmarkedChapterIds(prev => [...prev, chapterId]);
      triggerNotification(`Saved bookmark inside Ch. ${chapter.number}: ${chapter.title}`);
    }
  };

  // Handle Toggle Complete callback
  const handleToggleComplete = (chapterId: string) => {
    if (completedChapterIds.includes(chapterId)) {
      setCompletedChapterIds(prev => prev.filter(id => id !== chapterId));
      triggerNotification(`Chapter log revised: incomplete.`);
    } else {
      setCompletedChapterIds(prev => [...prev, chapterId]);
      triggerNotification(`Success! Marked chapter as fully digested.`);
    }
  };

  // Handle Next Chapter Pagination
  const handleNextChapter = () => {
    const currentIndex = chapters.findIndex(c => c.id === activeChapterId);
    if (currentIndex !== -1 && currentIndex < chapters.length - 1) {
      const nextChapter = chapters[currentIndex + 1];
      if (nextChapter.isLocked) {
        handleLockAlert(nextChapter.title);
      } else {
        setActiveChapterId(nextChapter.id);
        triggerNotification(`Advanced to Ch. ${nextChapter.number}: ${nextChapter.title}`);
      }
    }
  };

  // Handle Prev Chapter Pagination
  const handlePrevChapter = () => {
    const currentIndex = chapters.findIndex(c => c.id === activeChapterId);
    if (currentIndex > 0) {
      const prevChapter = chapters[currentIndex - 1];
      setActiveChapterId(prevChapter.id);
      triggerNotification(`Returned to Ch. ${prevChapter.number}`);
    }
  };

  // Handle Locked chapters alert
  const handleLockAlert = (chapterTitle: string) => {
    const chap = chapters.find(c => c.title === chapterTitle);
    if (chap) {
      setSelectedLockChapter({ title: chap.title, number: chap.number, id: chap.id });
      setShowUnlockModal(true);
    }
  };

  // Unlock the chapter successfully in their local session!
  const handleUnlockChapter = () => {
    if (!selectedLockChapter) return;
    
    // Update local state to unlock
    setChapters(prev => prev.map(c => {
      if (c.id === selectedLockChapter.id) {
        return { ...c, isLocked: false };
      }
      return c;
    }));

    setShowUnlockModal(false);
    setActiveChapterId(selectedLockChapter.id);
    triggerNotification(`Success! Ch. ${selectedLockChapter.number} unlocked using Void fragments.`);
    scrollToSection('reader');
  };

  const hasNextChapter = () => {
    const idx = chapters.findIndex(c => c.id === activeChapterId);
    return idx !== -1 && idx < chapters.length - 1;
  };

  const hasPrevChapter = () => {
    const idx = chapters.findIndex(c => c.id === activeChapterId);
    return idx > 0;
  };

  const handleSelectRecommendation = (novelTitle: string) => {
    triggerNotification(`Opening timeline corridor for: ${novelTitle}`);
    scrollToSection('hero');
  };

  return (
    <div className="relative min-h-screen bg-[#05070a] text-slate-200 selection:bg-indigo-500/30 selection:text-white overflow-hidden">
      
      {/* Ambient Background Glows from Immersive UI theme */}
      <div className="absolute top-[-10%] left-[-10%] w-[600px] h-[600px] rounded-full bg-indigo-900/15 blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-cyan-900/10 blur-[100px] pointer-events-none"></div>
      
      {/* 1. EMBEDDED NOTIFICATION TOAST */}
      <AnimatePresence>
        {notification && (
          <motion.div
            initial={{ opacity: 0, y: -50, x: "-50%" }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-6 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl glass-panel-heavy border-indigo-500/20 text-xs font-hud font-semibold text-gray-200 shadow-2xl flex items-center gap-2.5 max-w-sm sm:max-w-md"
          >
            <Sparkles size={14} className="text-indigo-400 shrink-0" />
            <span className="leading-relaxed text-left">{notification}</span>
            <button onClick={() => setNotification(null)} className="text-gray-500 hover:text-gray-300 ml-2">
              <X size={12} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 2. STICKY HUD NAVIGATION HEADER */}
      <header className="sticky top-0 z-40 w-full glass-panel border-b border-white/5 shadow-md">
        <div className="max-w-7xl mx-auto px-4 md:px-8 py-3.5 flex items-center justify-between">
          
          {/* Logo / Title brand */}
          <div 
            onClick={() => scrollToSection('hero')} 
            className="flex items-center gap-2 cursor-pointer select-none group"
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
              <Terminal size={14} />
            </div>
            <div className="text-left">
              <h1 className="text-sm font-display font-black tracking-widest text-white group-hover:text-indigo-300 transition-colors uppercase">
                Aetheris
              </h1>
              <span className="text-[9px] font-mono text-gray-500 uppercase tracking-widest">Digital Universe</span>
            </div>
          </div>

          {/* Nav Items anchors */}
          <nav className="hidden md:flex items-center gap-6 text-xs font-hud font-semibold tracking-wider text-gray-400">
            <button 
              onClick={() => scrollToSection('overview')} 
              className="hover:text-white transition-all cursor-pointer hover:translate-y-[-1px] active:translate-y-0"
            >
              LORE CODEX
            </button>
            <button 
              onClick={() => scrollToSection('world')} 
              className="hover:text-white transition-all cursor-pointer hover:translate-y-[-1px] active:translate-y-0"
            >
              CHARACTERS
            </button>
            <button 
              onClick={() => scrollToSection('chapters')} 
              className="hover:text-white transition-all cursor-pointer hover:translate-y-[-1px] active:translate-y-0"
            >
              ARCHIVES
            </button>
            <button 
              onClick={() => scrollToSection('reader')} 
              className="hover:text-indigo-300 text-indigo-400 transition-all cursor-pointer hover:translate-y-[-1px] active:translate-y-0 flex items-center gap-1 bg-indigo-500/10 px-3 py-1.5 rounded-lg border border-indigo-500/20"
            >
              <BookOpen size={11} />
              ACTIVE READER
            </button>
            <button 
              onClick={() => scrollToSection('comments')} 
              className="hover:text-white transition-all cursor-pointer hover:translate-y-[-1px] active:translate-y-0"
            >
              SANCTUARY
            </button>
          </nav>

          {/* Quick HUD controls / bookmark log */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => scrollToSection('chapters')}
              className="px-3 py-1.5 rounded-lg bg-slate-900 border border-white/5 hover:bg-slate-800 text-[10px] font-mono text-gray-400 hover:text-white transition-all cursor-pointer"
            >
              Log: {completedChapterIds.length} Read
            </button>
            <button
              onClick={() => scrollToSection('reader')}
              className="md:hidden p-2 rounded-lg bg-indigo-600 text-white cursor-pointer"
              title="Open Reader"
            >
              <BookOpen size={14} />
            </button>
          </div>

        </div>
      </header>

      {/* 3. CORE MULTI-SECTION ORCHESTRATION */}
      <main className="flex-grow">
        
        {/* Section 1: Hero view */}
        <Hero 
          novel={novelData} 
          onStartReading={handleStartReading}
          onViewChapters={() => scrollToSection('chapters')}
        />

        {/* Section 2: Story overview & world details */}
        <StoryOverview novel={novelData} />

        {/* Section 3: Characters & Factions */}
        <CharacterSection 
          characters={charactersData} 
          factions={factionsData} 
        />

        {/* Section 4: Chapters navigation list */}
        <ChapterBrowser 
          chapters={chapters}
          completedChapterIds={completedChapterIds}
          activeChapterId={activeChapterId}
          onSelectChapter={(id) => {
            setActiveChapterId(id);
            scrollToSection('reader');
          }}
          onLockAlert={handleLockAlert}
        />

        {/* Section 5: The active immersive reading terminal */}
        <ReaderSection 
          chapter={activeChapter}
          completedChapterIds={completedChapterIds}
          onToggleComplete={handleToggleComplete}
          onNextChapter={handleNextChapter}
          onPrevChapter={handlePrevChapter}
          hasNextChapter={hasNextChapter()}
          hasPrevChapter={hasPrevChapter()}
          onToggleBookmark={handleToggleBookmark}
          isBookmarked={bookmarkedChapterIds.includes(activeChapter.id)}
        />

        {/* Section 6: Comments discussion boards */}
        <CommentSection initialComments={commentsData} />

        {/* Section 7: Recommended literature */}
        <Recommendations 
          recommendations={recommendationsData} 
          onSelectRecommendation={handleSelectRecommendation}
        />

        {/* Section 8: Author profile highlights */}
        <AuthorSection novel={novelData} />

      </main>

      {/* 4. FOOTER */}
      <Footer onScrollToTop={() => scrollToSection('hero')} />

      {/* 5. GORGEOUS CUSTOM LOCK UNLOCK MODAL OVERLAY */}
      <AnimatePresence>
        {showUnlockModal && selectedLockChapter && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            
            {/* Dark glass backdrop filter */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowUnlockModal(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />

            {/* Modal Body card */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="relative w-full max-w-md p-6 rounded-3xl glass-panel-heavy border-indigo-500/20 text-center space-y-6 shadow-2xl z-10 text-gray-200 font-hud"
            >
              
              {/* Lock visual indicator */}
              <div className="w-14 h-14 rounded-full bg-indigo-950/40 border border-indigo-500/30 text-indigo-400 flex items-center justify-center mx-auto shadow-inner shadow-indigo-500/10">
                <Lock size={22} className="animate-pulse" />
              </div>

              <div className="space-y-2">
                <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-indigo-400">
                  Premium Passage
                </span>
                <h3 className="text-xl font-bold tracking-tight text-white leading-tight">
                  Unlock Chapter {selectedLockChapter.number}
                </h3>
                <p className="text-xs text-gray-400 leading-relaxed max-w-xs mx-auto">
                  “{selectedLockChapter.title}” is currently locked within the Elysium archives. Spend ether fragments to materialize the thread.
                </p>
              </div>

              {/* simulated payment info */}
              <div className="p-4 rounded-2xl bg-black/50 border border-white/5 grid grid-cols-2 gap-4 text-left text-xs font-sans">
                <div className="space-y-1">
                  <p className="text-[10px] font-mono text-gray-500 uppercase">Cost to materialize</p>
                  <p className="font-hud font-bold text-gray-200">10 Core Fragments</p>
                </div>
                <div className="space-y-1 border-l border-white/5 pl-4">
                  <p className="text-[10px] font-mono text-gray-500 uppercase">Your Balance</p>
                  <p className="font-hud font-bold text-emerald-400">45 Fragments</p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <button
                  onClick={() => setShowUnlockModal(false)}
                  className="flex-1 py-3 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-semibold tracking-wider text-gray-400 hover:text-white transition-all cursor-pointer"
                >
                  RETURN TO ARCHIVE
                </button>
                <button
                  onClick={handleUnlockChapter}
                  className="flex-1 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-xs font-bold tracking-wider text-white transition-all shadow-lg shadow-indigo-500/10 cursor-pointer"
                >
                  MATERIALIZE CHAPTER
                </button>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}

