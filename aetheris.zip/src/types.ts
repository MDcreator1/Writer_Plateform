/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface FeatureCard {
  id: string;
  icon: string;
  title: string;
  description: string;
  category: string;
  glowColor: string;
}

export interface ShowcaseProject {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  techStack: string[];
  metricLabel: string;
  metricValue: string;
  accentColor: string;
  coordinate: string;
}

export interface StoryNode {
  id: string;
  year: string;
  phase: string;
  title: string;
  description: string;
  highlight: string;
}

export interface ScrollState {
  scrollY: number;
  scrollProgress: number; // 0 to 1 across the entire document
  speed: number;
  direction: 'up' | 'down';
}
