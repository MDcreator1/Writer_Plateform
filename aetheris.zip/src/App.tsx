/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import Showcase from './components/Showcase';
import Story from './components/Story';
import CtaBanner from './components/CtaBanner';
import Footer from './components/Footer';
import AetherisCanvas from './components/AetherisCanvas';

export default function App() {
  const [scrollProgress, setScrollProgress] = useState(0);

  // Monitor scroll progress across the entire page (0 to 1)
  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      const docHeight = document.documentElement.scrollHeight;
      const winHeight = window.innerHeight;
      const totalScrollable = docHeight - winHeight;

      if (totalScrollable > 0) {
        const progress = scrollY / totalScrollable;
        setScrollProgress(progress);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    // Trigger initial calculation
    handleScroll();

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="relative min-h-screen w-full bg-[#030305] text-white selection:bg-cyan-500/20 selection:text-cyan-200">
      
      {/* FIXED 3D CANVASES AND DEEP BACKDROPS (Stays in background, morphs on scroll) */}
      <div className="fixed inset-0 w-full h-full z-0 pointer-events-none overflow-hidden">
        
        {/* Living interactive 3D particle orb/helix canvas */}
        <AetherisCanvas scrollProgress={scrollProgress} />
        
        {/* Soft background lighting grid overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#030305] via-transparent to-[#030305] opacity-40" />
      </div>

      {/* FLOATABLE FRONT-END COMPONENTS */}
      <div className="relative z-10 flex flex-col w-full">
        
        {/* Brand header */}
        <Navbar />

        {/* 1. Cinematic Hero Gate */}
        <Hero scrollProgress={scrollProgress} />

        {/* Section divider blur masks to separate depths beautifully */}
        <div className="h-[1px] w-full bg-gradient-to-r from-transparent via-zinc-800/80 to-transparent relative z-20" />

        {/* 2. Tactile Features Grid */}
        <div className="relative z-10 bg-[#030305]/40 backdrop-blur-sm">
          <Features />
        </div>

        <div className="h-[1px] w-full bg-gradient-to-r from-transparent via-zinc-800/80 to-transparent relative z-20" />

        {/* 3. Immersive Showcase State Controller */}
        <div className="relative z-10 bg-[#030305]/30">
          <Showcase />
        </div>

        <div className="h-[1px] w-full bg-gradient-to-r from-transparent via-zinc-800/80 to-transparent relative z-20" />

        {/* 4. Story Timeline Chronicle */}
        <div className="relative z-10 bg-[#030305]/40 backdrop-blur-xs">
          <Story />
        </div>

        <div className="h-[1px] w-full bg-gradient-to-r from-transparent via-zinc-800/80 to-transparent relative z-20" />

        {/* 5. Closing Secure Neural Channel CTA */}
        <div className="relative z-10 bg-transparent">
          <CtaBanner />
        </div>

        {/* 6. Premium Minimal Footer */}
        <Footer />

      </div>
    </div>
  );
}
