/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowUp, Github, Twitter, Globe, Linkedin } from 'lucide-react';

export default function Footer() {
  const scrollToTop = (e: React.MouseEvent) => {
    e.preventDefault();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const footerLinks = [
    {
      title: 'Grid Architecture',
      items: [
        { label: 'Quantum Shaders', href: '#features' },
        { label: 'Fluid Vector fields', href: '#features' },
        { label: 'Chronos Lerps', href: '#features' },
      ],
    },
    {
      title: 'Chronicles & Core',
      items: [
        { label: 'Synthesis Genesis', href: '#story' },
        { label: 'Crucible Testing', href: '#story' },
        { label: 'Engineering Files', href: '#story' },
      ],
    }
  ];

  return (
    <footer id="aetheris-footer" className="bg-[#030303] border-t border-white/10 py-16 md:py-24 relative overflow-hidden">
      
      {/* Decorative vertical divider line */}
      <div className="absolute top-0 right-1/3 w-[1px] h-36 bg-gradient-to-b from-white/10 to-transparent pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        
        {/* Top Segment */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 border-b border-white/10 pb-16">
          
          {/* Logo & Manifesto Block (6 Columns) */}
          <div className="lg:col-span-6 flex flex-col items-start gap-6">
            <div className="flex items-center gap-4">
              <div className="relative w-8 h-8 border border-white/40 flex items-center justify-center rotate-45">
                <div className="w-2 h-2 bg-white"></div>
              </div>
              <span className="font-sans font-bold text-sm tracking-[0.3em] text-white uppercase">
                Aetheris
              </span>
            </div>
            <p className="max-w-md font-sans text-xs text-white/40 leading-relaxed font-light">
              Aetheris structures the future of immersive spatial design. Creating beautiful, fluid vector journeys that combine physical layout boundaries with interactive math.
            </p>
          </div>

          {/* Navigation Links Blocks (6 Columns) */}
          <div className="lg:col-span-6 grid grid-cols-2 gap-8">
            {footerLinks.map((block, idx) => (
              <div key={idx} className="flex flex-col gap-5">
                <h4 className="font-mono text-[9px] tracking-[0.25em] text-white/40 uppercase font-bold">
                  {block.title}
                </h4>
                <ul className="flex flex-col gap-3.5">
                  {block.items.map((link, linkIdx) => (
                    <li key={linkIdx}>
                      <a
                        href={link.href}
                        className="font-sans text-xs text-white/60 hover:text-white transition-colors font-light"
                      >
                        {link.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

        </div>

        {/* Bottom copyright details and anchor scroll (Actions) */}
        <div className="pt-10 flex flex-col md:flex-row items-center justify-between gap-6 select-none">
          
          {/* Left copyright details */}
          <div className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left">
            <span className="font-mono text-[9px] tracking-wider text-white/30 uppercase">
              © {new Date().getFullYear()} AETHERIS LABS. ALL RIGHTS RESERVED.
            </span>
            <span className="hidden sm:inline text-white/10">|</span>
            <span className="font-mono text-[9px] tracking-wider text-white/30 uppercase">
              LICENSED UNDER APACHE-2.0
            </span>
          </div>

          {/* Right Floating Anchor */}
          <div className="flex items-center gap-6">
            
            {/* Minimal social links */}
            <div className="flex items-center gap-4">
              <a href="#" className="w-8 h-8 rounded-full border border-white/10 bg-white/5 text-white/50 hover:text-white hover:border-cyan-400/40 flex items-center justify-center transition-all duration-300">
                <Twitter className="w-3.5 h-3.5" />
              </a>
              <a href="#" className="w-8 h-8 rounded-full border border-white/10 bg-white/5 text-white/50 hover:text-white hover:border-cyan-400/40 flex items-center justify-center transition-all duration-300">
                <Github className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* Scroll-to-top button */}
            <a
              href="#"
              onClick={scrollToTop}
              className="w-10 h-10 rounded-full border border-white/10 bg-white/5 text-white/50 hover:text-white hover:border-cyan-400/40 flex items-center justify-center transition-all duration-300"
            >
              <ArrowUp className="w-4 h-4" />
            </a>
          </div>

        </div>

      </div>
    </footer>
  );
}
