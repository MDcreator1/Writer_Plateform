/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { ChevronDown, Sparkles, ArrowRight } from 'lucide-react';

interface HeroProps {
  scrollProgress: number;
}

export default function Hero({ scrollProgress }: HeroProps) {
  // Translate title slightly upward on scroll for layered parallax
  const textTranslateY = scrollProgress * -150;
  const opacityFade = Math.max(0, 1 - scrollProgress * 1.8);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 40, opacity: 0, filter: 'blur(10px)', scale: 0.96 },
    visible: {
      y: 0,
      opacity: 1,
      filter: 'blur(0px)',
      scale: 1,
      transition: {
        duration: 1.4,
        ease: [0.16, 1, 0.3, 1], // Custom cubic-bezier for liquid response
      },
    },
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen w-full flex items-center justify-center overflow-hidden bg-[#030303] px-6 md:px-12 pt-24"
    >
      {/* Cinematic Background Elements from Immersive UI Theme */}
      <div className="absolute inset-0 pointer-events-none z-0">
        <motion.div 
          style={{ y: scrollProgress * -180, opacity: opacityFade }}
          className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-indigo-900/20 rounded-full blur-[120px]"
        />
        <motion.div 
          style={{ y: scrollProgress * 180, opacity: opacityFade }}
          className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-cyan-900/15 rounded-full blur-[100px]"
        />
        <div 
          className="absolute inset-0 opacity-[0.03]" 
          style={{ 
            backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', 
            backgroundSize: '40px 40px' 
          }}
        ></div>
      </div>

      {/* Left HUD Vertical Social Bar */}
      <motion.div 
        style={{ y: scrollProgress * -80 - (window.innerHeight / 2 * 0), opacity: opacityFade }}
        className="absolute hidden xl:flex top-1/2 left-8 -translate-y-1/2 flex-col gap-12 text-[9px] font-bold tracking-[0.3em] text-white/20 uppercase z-10 [writing-mode:vertical-lr] rotate-180"
      >
        <a href="#" className="hover:text-white/60 transition-colors cursor-pointer">INSTAGRAM</a>
        <a href="#" className="hover:text-white/60 transition-colors cursor-pointer">TWITTER</a>
        <a href="#" className="hover:text-white/60 transition-colors cursor-pointer">BEHANCE</a>
      </motion.div>
      
      {/* Right HUD Step Indicator */}
      <motion.div 
        style={{ y: scrollProgress * 80 - (window.innerHeight / 2 * 0), opacity: opacityFade }}
        className="absolute hidden xl:flex top-1/2 right-8 -translate-y-1/2 z-10"
      >
        <div className="flex flex-col items-center gap-4">
           <div className="w-[1px] h-16 bg-white/10"></div>
           <span className="text-[10px] font-mono text-cyan-400 tracking-tighter">01/05</span>
           <div className="w-[1px] h-16 bg-white/10"></div>
        </div>
      </motion.div>

      {/* Main Content Area */}
      <div className="relative max-w-5xl mx-auto z-10 text-center flex flex-col items-center">
        
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          style={{ y: textTranslateY, opacity: opacityFade }}
          className="flex flex-col items-center select-none"
        >
          {/* Subtle Accent Pill */}
          <motion.div
            variants={itemVariants}
            className="text-[11px] uppercase tracking-[0.6em] mb-4 text-cyan-400 font-semibold"
          >
            CHAPTER 01: INITIATION
          </motion.div>

          {/* Majestic Hero Headline in Immersive UI Extra-Light & Medium Italic design */}
          <motion.h1
            variants={itemVariants}
            className="font-sans text-[60px] sm:text-[80px] md:text-[100px] lg:text-[110px] font-extralight tracking-[-0.04em] leading-[0.85] mb-8 text-white text-center"
          >
            AETHERIS<br/>
            <span className="font-medium italic tracking-[-0.02em] ml-16 sm:ml-24 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-zinc-200 to-indigo-400">
              BEYOND
            </span>
          </motion.h1>

          {/* Understated Supporting Subheading */}
          <motion.p
            variants={itemVariants}
            className="max-w-md text-white/40 text-[13px] leading-relaxed tracking-wide font-light mb-12 px-2"
          >
            Immerse yourself in a layered digital odyssey where physics meets aesthetics. A premium journey crafted for the vanguard of the new web.
          </motion.p>

          {/* Action CTAs */}
          <motion.div
            variants={itemVariants}
            className="flex flex-col sm:flex-row items-center gap-5 justify-center w-full sm:w-auto"
          >
            <a
              href="#features"
              className="px-8 py-3 bg-white text-black font-semibold rounded-full text-xs font-mono tracking-widest uppercase hover:bg-cyan-500 hover:text-white transition-all duration-500 shadow-xl shadow-cyan-500/5"
            >
              Examine the Forge
            </a>

            <a
              href="#showcase"
              className="px-8 py-3 border border-white/10 bg-white/5 backdrop-blur-md rounded-full text-xs font-mono tracking-widest uppercase text-white hover:bg-white hover:text-black transition-all duration-300"
            >
              Explore Chronicles
            </a>
          </motion.div>

        </motion.div>
      </div>

      {/* Bottom Interactive Layer with Dynamic Scene Progress */}
      <div className="absolute bottom-10 left-6 right-6 md:left-12 md:right-12 z-10 flex items-end justify-between select-none pointer-events-none">
        
        {/* Floating Scene Progress Indicator */}
        <div className="flex items-center gap-6">
          <div className="flex flex-col items-start gap-1">
            <span className="text-[9px] font-bold tracking-widest text-white/40">SCENE PROGRESS</span>
            <div className="flex gap-1 items-center">
              <div className={`w-2 h-2 rounded-full transition-colors duration-500 ${scrollProgress < 0.25 ? 'bg-cyan-400' : 'border border-white/20'}`}></div>
              <div className="w-12 h-[2px] bg-white/10"></div>
              <div className={`w-2 h-2 rounded-full transition-colors duration-500 ${scrollProgress >= 0.25 && scrollProgress < 0.75 ? 'bg-cyan-400' : 'border border-white/20'}`}></div>
              <div className="w-12 h-[2px] bg-white/10"></div>
              <div className={`w-2 h-2 rounded-full transition-colors duration-500 ${scrollProgress >= 0.75 ? 'bg-cyan-400' : 'border border-white/20'}`}></div>
            </div>
          </div>
        </div>

        {/* Scroll down mouse/laser tracker */}
        <div className="flex items-center gap-4">
          <div className="flex flex-col gap-2 items-center">
            <div className="w-[1px] h-10 bg-gradient-to-b from-transparent via-cyan-400 to-transparent"></div>
            <span className="text-[9px] [writing-mode:vertical-lr] rotate-180 uppercase tracking-[0.4em] text-white/40">Explore Depth</span>
          </div>
        </div>

      </div>
    </section>
  );
}
