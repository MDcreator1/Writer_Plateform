/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { Compass, Lightbulb, Map, Target } from 'lucide-react';
import { StoryNode } from '../types';

export default function Story() {
  const narrative: StoryNode[] = [
    {
      id: 's1',
      year: 'PHASE I',
      phase: '2024 // SYNTHESIS',
      title: 'The Mathematical Seed',
      description: 'Conceptualization of a unified canvas architecture that blends geometric layouts with deep 3D space. We established the basic math equations for perspective rendering, mapping spherical coordinates in 2D.',
      highlight: 'Establish vector projection matrices',
    },
    {
      id: 's2',
      year: 'PHASE II',
      phase: '2025 // CRUCIBLE',
      title: 'Spatial Engineering',
      description: 'Developing the real-time scroll calculator. We integrated interpolation engines that map standard scroll actions directly into spatial geometry, warping shapes to match document velocity.',
      highlight: 'Fluid physics and scroll warping',
    },
    {
      id: 's3',
      year: 'PHASE III',
      phase: '2026 // HORIZON',
      title: 'Quantum Convergence',
      description: 'Merging physical web layouts with interactive particle fields. The current release creates an elegant, tactile experience where DOM components coexist with simulated physics, responding to client gaze and scroll.',
      highlight: 'Full multi-dimensional convergence',
    }
  ];

  return (
    <section id="story" className="relative py-28 md:py-36 w-full bg-[#030305] overflow-hidden">
      
      {/* Decorative vertical line in background */}
      <div className="absolute top-0 right-1/4 w-[1px] h-full bg-gradient-to-b from-transparent via-zinc-800 to-transparent pointer-events-none" />

      <div className="max-w-6xl mx-auto px-6 md:px-12 relative z-10">
        
        {/* Section Title */}
        <div className="max-w-xl mb-20 md:mb-28">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full border border-white/10 bg-white/5 text-zinc-400 font-mono text-[9px] tracking-widest uppercase mb-5">
            <Compass className="w-3.5 h-3.5 text-cyan-400" />
            <span>Narrative Chronology</span>
          </div>
          <h2 className="font-sans text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight leading-tight">
            The Chronicle of Aetheris
          </h2>
          <p className="font-sans text-sm md:text-base text-white/50 font-normal mt-4 leading-relaxed">
            Witness the development history of our spatial layout platform. We started with basic vector mathematics and ended with living interactive galaxies.
          </p>
        </div>

        {/* Timeline Tracks */}
        <div className="relative pl-8 md:pl-16 border-l border-white/10 flex flex-col gap-16 md:gap-24">
          
          {narrative.map((node, index) => (
            <motion.div
              key={node.id}
              initial={{ opacity: 0, y: 50, scale: 0.97, filter: 'blur(5px)' }}
              whileInView={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }}
              viewport={{ once: true, margin: '-80px' }}
              transition={{ duration: 1.1, delay: index * 0.12, ease: [0.16, 1, 0.3, 1] }}
              className="relative flex flex-col lg:flex-row lg:items-start gap-8 lg:gap-16 group"
            >
              
              {/* Timeline Indicator Dot with scroll-view active state */}
              <motion.div 
                initial={{ scale: 0.85, borderColor: 'rgba(255, 255, 255, 0.15)' }}
                whileInView={{ scale: 1.25, borderColor: 'rgba(34, 211, 238, 0.8)' }}
                viewport={{ once: false, margin: '-160px' }}
                transition={{ duration: 0.5, ease: 'easeOut' }}
                className="absolute -left-[37px] md:-left-[69px] top-1.5 w-4 h-4 rounded-full bg-black border-2 flex items-center justify-center z-10 transition-shadow duration-500 cursor-pointer"
              >
                <motion.span 
                  initial={{ backgroundColor: 'rgba(255, 255, 255, 0.15)' }}
                  whileInView={{ backgroundColor: 'rgb(34, 211, 238)' }}
                  viewport={{ once: false, margin: '-160px' }}
                  className="w-1.5 h-1.5 rounded-full" 
                />
              </motion.div>

              {/* Phase / Date Column */}
              <div className="lg:w-48 shrink-0">
                <div className="font-mono text-xs font-bold text-cyan-400 tracking-[0.25em] uppercase mb-1">
                  {node.year}
                </div>
                <div className="font-mono text-[10px] text-white/40 tracking-wider uppercase">
                  {node.phase}
                </div>
              </div>

              {/* Main Narrative Card in Glassmorphic Immersive UI Style */}
              <div className="flex-1 p-8 rounded-xl border border-white/10 bg-white/5 backdrop-blur-xl hover:border-cyan-400/30 transition-colors duration-500 relative group shadow-lg">
                
                {/* Thin top-left corner marker */}
                <div className="absolute top-0 left-0 w-3 h-[1.5px] bg-white/30 group-hover:bg-cyan-400 transition-colors duration-500" />
                <div className="absolute top-0 left-0 w-[1.5px] h-3 bg-white/30 group-hover:bg-cyan-400 transition-colors duration-500" />

                <h3 className="font-sans text-xl font-bold text-white tracking-tight mb-3.5 group-hover:text-cyan-200 transition-colors">
                  {node.title}
                </h3>
                <p className="font-sans text-sm text-white/70 leading-relaxed font-light mb-6">
                  {node.description}
                </p>

                {/* Highlight specification badge */}
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border border-white/5 bg-white/5 text-white/50 font-mono text-[9px] tracking-wider uppercase">
                  <span className="h-1 w-1 rounded-full bg-cyan-400" />
                  <span>Key Matrix: {node.highlight}</span>
                </div>

              </div>

            </motion.div>
          ))}

        </div>

      </div>
    </section>
  );
}
