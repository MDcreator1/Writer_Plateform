/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sliders, Activity, Database, Flame, Gauge, Zap } from 'lucide-react';
import { ShowcaseProject } from '../types';

export default function Showcase() {
  const [activeTab, setActiveTab] = useState<string>('p1');

  const systems: ShowcaseProject[] = [
    {
      id: 'p1',
      title: 'Spectra Engine',
      subtitle: 'VOLUMETRIC CHROMATIC GRID',
      description: 'The Spectra Engine maps high-dimensional vector color arrays in real time. It utilizes spatial coordinates to blend atmospheric shades, rendering smooth transition gradients across layout intersections.',
      techStack: ['Vector Shaders', 'WebGPU Pipelines', 'Luma Tracing'],
      metricLabel: 'Space Refraction Ratio',
      metricValue: '1.428 // AD',
      accentColor: 'from-cyan-400 to-emerald-500',
      coordinate: 'SEC-01 // LAT-A4',
    },
    {
      id: 'p2',
      title: 'Hyperion Core',
      subtitle: 'COGNITIVE GEOMETRIC FORGE',
      description: 'Hyperion acts as the central logic unit, controlling the particle physics and fluid mechanics of the canvas stardust. It dynamically adjusts particle velocity and dispersion vectors in response to client triggers.',
      techStack: ['Matrix Math', 'Fluid Dynamics', 'Physics Solver'],
      metricLabel: 'Vector Repulsion Force',
      metricValue: '850.5 // kN',
      accentColor: 'from-violet-500 to-fuchsia-600',
      coordinate: 'SEC-02 // HYP-D9',
    },
    {
      id: 'p3',
      title: 'Chronos Grid',
      subtitle: 'TEMPORAL SCROLL CALCULATOR',
      description: 'The Chronos Grid measures client scrolling vectors, calculating velocity gradients and acceleration matrices. This feeds back into the rendering pipeline to warp the background geometry into helices.',
      techStack: ['Scroll-driven Interpolation', 'Lerp Solvers', 'Event Threading'],
      metricLabel: 'Interpolation Speed',
      metricValue: '0.012s // ACC',
      accentColor: 'from-amber-400 to-orange-500',
      coordinate: 'SEC-03 // CHR-X1',
    },
  ];

  const currentSystem = systems.find((s) => s.id === activeTab) || systems[0];

  return (
    <section id="showcase" className="relative py-28 md:py-36 w-full bg-[#030305] overflow-hidden">
      
      {/* Decorative large ambient lights */}
      <div className="absolute top-1/2 left-0 -translate-y-1/2 w-96 h-96 rounded-full bg-cyan-950/5 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-96 h-96 rounded-full bg-violet-950/5 blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        
        {/* Section Title */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end justify-between mb-16 md:mb-24 gap-6"
        >
          <div className="max-w-xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full border border-white/10 bg-white/5 text-zinc-400 font-mono text-[9px] tracking-widest uppercase mb-5">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              <span>Modular State Explorer</span>
            </div>
            <h2 className="font-sans text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight leading-tight">
              Interactive Systems Control
            </h2>
            <p className="font-sans text-sm md:text-base text-white/50 font-normal mt-4 leading-relaxed">
              Toggle the parameters below to witness how the Aetheris pipeline restructures its sub-systems, updating visual layers and physical parameters instantly.
            </p>
          </div>

          {/* Quick Tab Selector in Round Glassmorphic style */}
          <div className="flex items-center gap-2.5 p-1.5 rounded-full border border-white/10 bg-white/5 backdrop-blur-md self-start md:self-auto overflow-x-auto w-full md:w-auto">
            {systems.map((sys) => (
              <button
                key={sys.id}
                onClick={() => setActiveTab(sys.id)}
                className={`flex-1 md:flex-none px-5 py-2.5 rounded-full text-xs font-mono tracking-wider uppercase font-semibold transition-all duration-300 whitespace-nowrap ${
                  activeTab === sys.id
                    ? 'bg-white text-black shadow-md'
                    : 'text-white/60 hover:text-white hover:bg-white/5'
                }`}
              >
                {sys.title.split(' ')[0]}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Dashboard Display Matrix */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Left Panel: In-depth Technical Spec (7 columns) in glassmorphic style */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 flex flex-col justify-between p-8 md:p-12 rounded-xl border border-white/10 bg-white/5 backdrop-blur-xl relative overflow-hidden shadow-2xl shadow-black/60"
          >
            
            {/* Visual subtle graph grid back */}
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(255,255,255,0.01)_0%,transparent_65%)] pointer-events-none" />

            <AnimatePresence mode="wait">
              <motion.div
                key={currentSystem.id}
                initial={{ opacity: 0, x: -15 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 15 }}
                transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                className="flex flex-col h-full justify-between gap-10"
              >
                <div>
                  {/* Top Header */}
                  <div className="flex items-center justify-between border-b border-white/10 pb-6 mb-8">
                    <span className="font-mono text-[10px] tracking-widest text-cyan-400 uppercase">
                      {currentSystem.subtitle}
                    </span>
                    <span className="font-mono text-[9px] tracking-widest text-white/30">
                      {currentSystem.coordinate}
                    </span>
                  </div>

                  {/* Main Title and Description */}
                  <h3 className="font-sans text-3xl md:text-4xl font-black text-white tracking-tight mb-6">
                    {currentSystem.title}
                  </h3>
                  <p className="font-sans text-sm md:text-base text-white/75 leading-relaxed font-normal mb-8">
                    {currentSystem.description}
                  </p>

                  {/* Built-with Chips with staggering entry on state switch */}
                  <div className="flex flex-wrap gap-2.5">
                    {currentSystem.techStack.map((tech, idx) => (
                      <motion.span
                        key={`${currentSystem.id}-${tech}`}
                        initial={{ opacity: 0, scale: 0.85, y: 8 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        transition={{ duration: 0.4, delay: idx * 0.08, ease: [0.16, 1, 0.3, 1] }}
                        className="px-3 py-1 rounded-md border border-white/10 bg-white/5 text-white/60 font-mono text-[9px] tracking-wider uppercase"
                      >
                        {tech}
                      </motion.span>
                    ))}
                  </div>
                </div>

                {/* Metric Output Frame */}
                <div className="mt-6 p-6 rounded-xl border border-white/10 bg-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center">
                      <Sliders className="w-4 h-4 text-cyan-400" />
                    </div>
                    <div>
                      <div className="font-mono text-[9px] tracking-wider text-white/40 uppercase">
                        Current Telemetry Field
                      </div>
                      <div className="font-sans text-sm font-semibold text-white mt-0.5">
                        {currentSystem.metricLabel}
                      </div>
                    </div>
                  </div>
                  <div className="font-mono text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-white to-zinc-400">
                    {currentSystem.metricValue}
                  </div>
                </div>

              </motion.div>
            </AnimatePresence>

          </motion.div>

          {/* Right Panel: Simulated 3D Glass Portal Graphic (5 columns) with slide-in from right */}
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 flex flex-col justify-center items-center p-8 rounded-xl border border-white/10 bg-white/5 backdrop-blur-xl relative overflow-hidden shadow-xl min-h-[400px]"
          >
            
            <AnimatePresence mode="wait">
              <motion.div
                key={currentSystem.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                className="relative flex flex-col items-center justify-center w-full h-full"
              >
                {/* 3D Glass Portal Design Elements from the theme */}
                <div className="relative w-64 h-64 flex items-center justify-center">
                  
                  {/* Outer Glow */}
                  <div className="absolute inset-0 rounded-full border border-white/5 shadow-[0_0_80px_rgba(99,102,241,0.15)] pointer-events-none"></div>
                  
                  {/* Rotating Rings (Simulated dynamic rotations) */}
                  <div className="absolute inset-4 rounded-full border border-dashed border-white/10 opacity-40 animate-spin-slow"></div>
                  <div className="absolute inset-10 rounded-full border border-white/20 opacity-20 animate-spin-reverse"></div>
                  
                  {/* Inner Glass Orb */}
                  <div className="absolute inset-[44px] bg-gradient-to-br from-white/15 to-transparent backdrop-blur-2xl rounded-full border border-white/25 shadow-2xl flex items-center justify-center group overflow-hidden">
                     <div className="absolute w-full h-full bg-[radial-gradient(circle_at_30%_30%,rgba(255,255,255,0.25),transparent)]"></div>
                     <div className="w-[85%] h-[85%] border border-cyan-400/20 rounded-full flex items-center justify-center">
                        
                        {/* Interactive Center Icon */}
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ duration: 25, repeat: Infinity, ease: 'linear' }}
                          className={`relative w-16 h-16 rounded-full bg-gradient-to-br ${currentSystem.accentColor} p-[1.5px] shadow-lg shadow-black/40`}
                        >
                          <div className="w-full h-full rounded-full bg-zinc-950 flex items-center justify-center">
                            {currentSystem.id === 'p1' && <Gauge className="w-6 h-6 text-cyan-400" />}
                            {currentSystem.id === 'p2' && <Zap className="w-6 h-6 text-violet-400" />}
                            {currentSystem.id === 'p3' && <Flame className="w-6 h-6 text-amber-400" />}
                          </div>
                        </motion.div>

                     </div>
                  </div>

                </div>

                <div className="mt-8 text-center select-none">
                  <div className="font-mono text-[9px] tracking-widest text-white/40 uppercase">
                    System Core Signature
                  </div>
                  <div className="font-sans text-xs font-semibold text-white mt-1.5 tracking-wider">
                    {currentSystem.title.toUpperCase()} // ACTIVE
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>

          </motion.div>

        </div>

      </div>
    </section>
  );
}
