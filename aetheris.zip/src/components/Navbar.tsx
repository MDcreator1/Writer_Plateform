/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Shield, Cpu, RefreshCw, Layers, Menu, X, Globe, Terminal } from 'lucide-react';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [telemetryTime, setTelemetryTime] = useState('');
  const [visible, setVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  // Update telemetry time clock to simulate live mainframe clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const timeStr = now.toISOString().slice(11, 19);
      setTelemetryTime(timeStr);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Monitor scroll behavior: set scrolled background state and direction-driven hide/show
  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      // Glassmorphic background trigger
      if (currentScrollY > 40) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }

      // Hide navbar when scrolling down, show when scrolling up
      if (currentScrollY > lastScrollY && currentScrollY > 150) {
        setVisible(false); // scrolling down
      } else {
        setVisible(true); // scrolling up or near top
      }
      
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  const menuItems = [
    { label: 'Quantum Forge', href: '#features' },
    { label: 'Neural Core', href: '#showcase' },
    { label: 'Chronicles', href: '#story' },
    { label: 'Aether Grid', href: '#cta' }
  ];

  return (
    <motion.header
      id="aetheris-navbar"
      initial={{ y: -50, opacity: 0 }}
      animate={{ 
        y: visible ? 0 : -90, 
        opacity: visible ? 1 : 0 
      }}
      transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 border-b ${
        scrolled
          ? 'bg-[#030305]/75 backdrop-blur-xl border-zinc-800/40 py-4 shadow-xl shadow-black/20'
          : 'bg-transparent border-transparent py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between">
        
        {/* Brand Logo with Premium Letter Spacing and Glow Accent */}
        <a href="#" className="flex items-center gap-4 group">
          <div className="relative w-8 h-8 border border-white/40 flex items-center justify-center rotate-45 group-hover:border-cyan-400 transition-colors duration-500 cursor-pointer">
            <div className="w-2 h-2 bg-white group-hover:bg-cyan-400 transition-colors duration-500"></div>
          </div>
          <div className="flex flex-col">
            <span className="text-[11px] font-sans font-bold tracking-[0.3em] text-white opacity-85 group-hover:text-cyan-300 transition-colors duration-500 uppercase">
              Aetheris / Studio
            </span>
            <span className="font-mono text-[8px] tracking-[0.18em] text-zinc-600 uppercase">
              SYSTEM MATRIX
            </span>
          </div>
        </a>

        {/* Desktop Navigation Link Cluster */}
        <nav className="hidden lg:flex items-center gap-10 text-[10px] font-medium tracking-[0.2em] uppercase text-white/60">
          {menuItems.map((item, idx) => (
            <a
              key={idx}
              href={item.href}
              className="hover:text-white transition-colors"
            >
              {item.label}
            </a>
          ))}
        </nav>

        {/* Live Telemetry Node Badge and Action CTAs */}
        <div className="hidden md:flex items-center gap-6">
          {/* Mainframe status display */}
          <div className="hidden lg:flex items-center gap-2.5 px-3.5 py-1.5 rounded-full border border-zinc-950 bg-zinc-950/40 text-zinc-500 font-mono text-[9px] tracking-widest">
            <span className="relative flex h-1.5 w-1.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-cyan-500"></span>
            </span>
            <span>CORE NODE // ONLINE</span>
            <span className="text-zinc-700">|</span>
            <span className="text-cyan-400">{telemetryTime || '11:55:54'}</span>
          </div>

          <a
            href="#cta"
            className="px-6 py-2 border border-white/10 bg-white/5 backdrop-blur-md rounded-full text-xs font-mono tracking-widest uppercase text-white hover:bg-white hover:text-black transition-all duration-300"
          >
            Initialize
          </a>
        </div>

        {/* Mobile menu trigger button */}
        <div className="flex lg:hidden items-center gap-4">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="w-10 h-10 flex items-center justify-center rounded-lg border border-zinc-800 bg-zinc-950/50 text-white hover:border-cyan-500/50 transition-colors"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

      </div>

      {/* Mobile Glassmorphic Navigation Drawer */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.4, ease: 'easeInOut' }}
            className="lg:hidden w-full border-t border-zinc-800 bg-[#030305]/95 backdrop-blur-2xl overflow-hidden"
          >
            <div className="px-6 py-8 flex flex-col gap-5">
              {menuItems.map((item, idx) => (
                <a
                  key={idx}
                  href={item.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-sm uppercase tracking-widest text-zinc-300 hover:text-cyan-400 transition-colors py-1"
                >
                  {item.label}
                </a>
              ))}
              <div className="h-[1px] bg-zinc-800/60 my-2" />
              <div className="flex items-center justify-between font-mono text-[9px] tracking-wider text-zinc-500">
                <span className="flex items-center gap-1.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  STABLE GRID
                </span>
                <span>{telemetryTime} UTC</span>
              </div>
              <a
                href="#cta"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full text-center py-3 rounded-lg text-xs font-mono tracking-wider uppercase font-semibold bg-white text-black hover:bg-cyan-500 hover:text-white transition-all"
              >
                Initialize Portal
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
