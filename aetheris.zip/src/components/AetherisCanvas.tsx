/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';

interface AetherisCanvasProps {
  scrollProgress: number; // 0 to 1
}

interface Particle {
  x: number;
  y: number;
  z: number;
  originalX: number;
  originalY: number;
  originalZ: number;
  color: string;
  size: number;
  theta: number; // Angular coordinates
  phi: number;
  r: number; // Distance from center
  phase: number; // Sine phase for pulsation
}

export default function AetherisCanvas({ scrollProgress }: AetherisCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mouseRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0, active: false });
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

  // Handle container resizing cleanly
  useEffect(() => {
    if (!containerRef.current) return;

    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        setDimensions({ width, height });
      }
    });

    resizeObserver.observe(containerRef.current);
    
    // Set initial size
    const initialRect = containerRef.current.getBoundingClientRect();
    setDimensions({ width: initialRect.width, height: initialRect.height });

    return () => resizeObserver.disconnect();
  }, []);

  // Update canvas sizing
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.width = dimensions.width;
    canvas.height = dimensions.height;
  }, [dimensions]);

  // Track mouse coordinates relative to canvas center
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!canvasRef.current) return;
      const rect = canvasRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left - rect.width / 2;
      const y = e.clientY - rect.top - rect.height / 2;
      mouseRef.current.targetX = x;
      mouseRef.current.targetY = y;
      mouseRef.current.active = true;
    };

    const handleMouseLeave = () => {
      mouseRef.current.active = false;
    };

    window.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseleave', handleMouseLeave);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, []);

  // Core 3D engine loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Constants
    const particleCount = 750;
    const particles: Particle[] = [];
    const perspective = 450;
    
    // Smooth scroll interpolation (lerp)
    let currentScrollProgress = 0;
    
    // Initialize particles in a spherical formation
    for (let i = 0; i < particleCount; i++) {
      // Golden ratio distribution for perfectly even sphere packing
      const phi = Math.acos(-1 + (2 * i) / particleCount);
      const theta = Math.sqrt(particleCount * Math.PI) * phi;
      const r = 160; // Base sphere radius

      const x = r * Math.sin(phi) * Math.cos(theta);
      const y = r * Math.sin(phi) * Math.sin(theta);
      const z = r * Math.cos(phi);

      // Define rich cinematic color palettes based on particle indices
      // A mix of deep space cyan, royal violet, cosmic gold, and crystalline silver
      let color = 'rgba(6, 182, 212, 0.85)'; // Cyan
      if (i % 3 === 1) {
        color = 'rgba(139, 92, 246, 0.85)'; // Violet
      } else if (i % 6 === 0) {
        color = 'rgba(234, 179, 8, 0.85)'; // Amber/Gold
      } else if (i % 5 === 0) {
        color = 'rgba(244, 244, 245, 0.9)'; // Silver-white
      }

      particles.push({
        x,
        y,
        z,
        originalX: x,
        originalY: y,
        originalZ: z,
        color,
        size: Math.random() * 2 + 1,
        theta,
        phi,
        r,
        phase: Math.random() * Math.PI * 2,
      });
    }

    // Rotations variables
    let angleY = 0.003;
    let angleX = 0.0015;
    
    // Frame loop
    let animationFrameId: number;

    const render = () => {
      // Clear with very slight alpha to create high-end trailing/ghosting motion effect
      ctx.fillStyle = 'rgba(3, 3, 5, 0.18)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;

      // Smoothly interpolate scroll progress for liquid feeling
      currentScrollProgress += (scrollProgress - currentScrollProgress) * 0.08;

      // Lerp mouse target for buttery response
      const mouse = mouseRef.current;
      mouse.x += (mouse.targetX - mouse.x) * 0.05;
      mouse.y += (mouse.targetY - mouse.y) * 0.05;

      // Base rotation shifts depending on mouse position and scroll state
      let rotSpeedY = angleY + (mouse.active ? mouse.x * 0.00002 : 0);
      let rotSpeedX = angleX + (mouse.active ? mouse.y * 0.00001 : 0);
      
      // Speed up rotation when user scrolls deep
      rotSpeedY += currentScrollProgress * 0.015;
      rotSpeedX += currentScrollProgress * 0.005;

      // Precalculate trig functions for rotation matrix
      const cosY = Math.cos(rotSpeedY);
      const sinY = Math.sin(rotSpeedY);
      const cosX = Math.cos(rotSpeedX);
      const sinX = Math.sin(rotSpeedX);

      // Sort particles by depth (Z index) before drawing to ensure proper 3D rendering occlusion
      const renderedPoints = particles.map((p, index) => {
        // Step 1: Rotate in 3D around Y axis
        let x1 = p.x * cosY - p.z * sinY;
        let z1 = p.x * sinY + p.z * cosY;

        // Step 2: Rotate around X axis
        let y2 = p.y * cosX - z1 * sinX;
        let z2 = p.y * sinX + z1 * cosX;

        // Save updated rotated coordinates back
        p.x = x1;
        p.y = y2;
        p.z = z2;

        // Step 3: Scroll-driven 3D Morphing behavior
        // As scroll progress goes from 0 to 1, we deform the sphere into a gorgeous double helix vortex
        // section 1: Sphere, section 2: Helix expand, section 3: Dynamic matrix grid
        let targetX = p.x;
        let targetY = p.y;
        let targetZ = p.z;

        if (currentScrollProgress > 0.05) {
          const factor = currentScrollProgress;
          
          // Double Helix transformation
          // Create twisting waves along the Z axis
          const twist = p.theta + factor * Math.PI * 4;
          const helixRadius = p.r * (1 + factor * 1.5);
          const helixHeight = (p.phi - Math.PI / 2) * 450 * factor;
          
          // Helix A and Helix B
          const isHelixA = index % 2 === 0;
          const hTheta = twist + (isHelixA ? 0 : Math.PI);
          
          const hX = helixRadius * Math.sin(p.phi) * Math.cos(hTheta);
          const hY = helixHeight;
          const hZ = helixRadius * Math.sin(p.phi) * Math.sin(hTheta);

          // Smoothly mix sphere with helix
          targetX = p.x * (1 - factor) + hX * factor;
          targetY = p.y * (1 - factor) + hY * factor;
          targetZ = p.z * (1 - factor) + hZ * factor;
        }

        // Step 4: Apply cursor gravity push
        if (mouse.active) {
          // Calculate distance to cursor projected in 2D or 3D
          const dx = targetX - mouse.x;
          const dy = targetY - mouse.y;
          const distSqr = dx * dx + dy * dy;
          const maxDist = 200;
          
          if (distSqr < maxDist * maxDist) {
            const dist = Math.sqrt(distSqr);
            // Push particles away proportional to distance (gravity pulse)
            const force = (maxDist - dist) / maxDist;
            const pushX = (dx / dist) * force * 45;
            const pushY = (dy / dist) * force * 45;
            
            targetX += pushX;
            targetY += pushY;
          }
        }

        // Dynamic particle glow pulse over time
        p.phase += 0.02;
        const pulse = Math.sin(p.phase) * 0.4 + 1.0;

        // Apply perspective projection formula
        const projectedZ = targetZ + perspective;
        const scale = perspective / Math.max(1, projectedZ);
        
        // Calculate screen coordinates
        const screenX = centerX + targetX * scale;
        const screenY = centerY + targetY * scale;

        return {
          sx: screenX,
          sy: screenY,
          sz: targetZ,
          scale,
          color: p.color,
          size: p.size * scale * pulse,
        };
      });

      // Sort points so we draw background elements (smaller Z) before foreground (larger Z)
      renderedPoints.sort((a, b) => b.sz - a.sz);

      // Step 5: Render projected particles with cinematic glow rings
      renderedPoints.forEach((pt) => {
        // Out of viewport pruning
        if (pt.sx < 0 || pt.sx > canvas.width || pt.sy < 0 || pt.sy > canvas.height) {
          return;
        }

        // Depth fog: further points are darker
        const alpha = Math.min(1.0, Math.max(0.1, (pt.sz + 300) / 600));
        
        // Draw glow accent behind brightest nodes
        if (pt.scale > 1.2 && Math.random() < 0.15) {
          ctx.beginPath();
          ctx.arc(pt.sx, pt.sy, pt.size * 3.5, 0, Math.PI * 2);
          ctx.fillStyle = pt.color.replace('0.85', '0.08').replace('0.9', '0.08');
          ctx.fill();
        }

        ctx.beginPath();
        ctx.arc(pt.sx, pt.sy, pt.size, 0, Math.PI * 2);
        
        // Format fill style with dynamic alpha
        let finalColor = pt.color;
        if (alpha < 0.95) {
          finalColor = pt.color
            .replace('0.85', (0.85 * alpha).toFixed(2))
            .replace('0.9', (0.9 * alpha).toFixed(2));
        }
        
        ctx.fillStyle = finalColor;
        ctx.fill();
      });

      // Draw light connection lines between very close foreground points for a futuristic grid feel
      // Limit checks to keep performance highly optimized
      ctx.lineWidth = 0.55;
      for (let i = 0; i < renderedPoints.length; i += 18) {
        const pt1 = renderedPoints[i];
        if (pt1.scale < 0.8) continue; // Skip distant background points
        
        for (let j = i + 1; j < Math.min(renderedPoints.length, i + 8); j++) {
          const pt2 = renderedPoints[j];
          if (pt2.scale < 0.8) continue;

          const dx = pt1.sx - pt2.sx;
          const dy = pt1.sy - pt2.sy;
          const dSqr = dx * dx + dy * dy;

          if (dSqr < 1800) { // Limit link length
            const alpha = (1 - Math.sqrt(dSqr) / Math.sqrt(1800)) * 0.18 * ((pt1.sz + pt2.sz) / 2 + 300) / 600;
            ctx.beginPath();
            ctx.moveTo(pt1.sx, pt1.sy);
            ctx.lineTo(pt2.sx, pt2.sy);
            ctx.strokeStyle = `rgba(139, 92, 246, ${alpha.toFixed(3)})`;
            ctx.stroke();
          }
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [scrollProgress]);

  return (
    <div
      ref={containerRef}
      className="absolute inset-0 w-full h-full pointer-events-none select-none z-0 overflow-hidden"
    >
      {/* Absolute canvas centered perfectly */}
      <canvas
        id="aetheris-3d-canvas"
        ref={canvasRef}
        className="w-full h-full block mix-blend-screen opacity-95 transition-opacity duration-700"
      />
    </div>
  );
}
