/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Shield, Sparkles, CheckCircle2, RefreshCw } from 'lucide-react';

export default function CtaBanner() {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'linking' | 'decrypting' | 'connected'>('idle');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    // Simulate encrypted secure uplink stages
    setStatus('linking');
    
    setTimeout(() => {
      setStatus('decrypting');
    }, 1500);

    setTimeout(() => {
      setStatus('connected');
    }, 3200);
  };

  return (
    <section id="cta" className="relative py-32 md:py-44 w-full bg-[#030305] overflow-hidden">
      
      {/* Absolute Vignette background lighting */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom,rgba(139,92,246,0.12)_0%,transparent_60%)] pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[30rem] h-[30rem] rounded-full bg-cyan-900/5 blur-[120px] pointer-events-none" />

      {/* Grid overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.003)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.003)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none" />

      <div className="max-w-4xl mx-auto px-6 md:px-12 relative z-10 text-center">
        
        {/* Cinematic Header */}
        <motion.div 
          initial={{ opacity: 0, y: 35 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col items-center mb-12"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/10 bg-white/5 text-zinc-400 font-mono text-[9px] tracking-[0.25em] uppercase mb-8"
          >
            <Shield className="w-3.5 h-3.5 text-cyan-400" />
            <span>Secure Neural Uplink Channel</span>
          </motion.div>

          <h2 className="font-sans text-[40px] sm:text-[50px] md:text-[60px] font-extralight tracking-[-0.04em] leading-[0.95] mb-6 uppercase text-white">
            Initialize the<br/>
            <span className="font-medium italic tracking-[-0.02em] bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-indigo-400">
              Convergence
            </span>
          </h2>

          <p className="max-w-xl font-sans text-sm md:text-base text-white/50 font-light leading-relaxed">
            Connect your coordinates to the Aetheris grid. Get notified of system patches, new spatial shaders, and dimensional rendering chronicles.
          </p>
        </motion.div>

        {/* Subscription Interactive Form Panel in Immersive UI Glassmorphic Card Style */}
        <motion.div 
          initial={{ opacity: 0, y: 40, scale: 0.96, filter: 'blur(5px)' }}
          whileInView={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
          className="max-w-md mx-auto p-8 rounded-xl border border-white/10 bg-white/5 backdrop-blur-xl relative overflow-hidden shadow-2xl shadow-black/80"
        >
          
          <AnimatePresence mode="wait">
            {status === 'idle' && (
              <motion.form
                key="form-idle"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                onSubmit={handleSubscribe}
                className="flex flex-col gap-4"
              >
                <div className="relative">
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email coordinate..."
                    className="w-full px-5 py-4 rounded-xl border border-white/10 bg-white/5 text-white font-sans text-sm placeholder-white/30 focus:outline-none focus:border-cyan-400/50 focus:shadow-[0_0_20px_rgba(6,182,212,0.1)] transition-all duration-300"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-3.5 bg-white text-black font-semibold rounded-full text-xs font-mono tracking-widest uppercase hover:bg-cyan-500 hover:text-white transition-all duration-500 flex items-center justify-center gap-2 group cursor-pointer shadow-lg shadow-white/5"
                >
                  Connect Channel
                  <Send className="w-3.5 h-3.5 group-hover:translate-x-1.5 transition-transform" />
                </button>
              </motion.form>
            )}

            {(status === 'linking' || status === 'decrypting') && (
              <motion.div
                key="form-loading"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="py-6 flex flex-col items-center justify-center gap-6"
              >
                <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin" />
                <div className="flex flex-col items-center gap-2">
                  <div className="font-mono text-[10px] tracking-widest text-cyan-400 font-bold uppercase animate-pulse">
                    {status === 'linking' ? 'ESTABLISHING UPLINK...' : 'DECRYPTING CORRELATION...'}
                  </div>
                  <div className="font-mono text-[9px] tracking-widest text-zinc-500 uppercase">
                    SSL_TLS // KEY_PAIR_HANDSHAKE
                  </div>
                </div>
              </motion.div>
            )}

            {status === 'connected' && (
              <motion.div
                key="form-success"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="py-6 flex flex-col items-center justify-center gap-5 text-center"
              >
                <CheckCircle2 className="w-12 h-12 text-emerald-400" />
                <div>
                  <h4 className="font-sans text-lg font-bold text-white mb-1.5">
                    Uplink Configured Successfully
                  </h4>
                  <p className="font-sans text-xs text-zinc-400 leading-normal max-w-xs mx-auto">
                    Welcome to Aetheris. Your email <span className="text-cyan-400 font-mono">{email}</span> is now bonded with node matrices.
                  </p>
                </div>
                <div className="font-mono text-[8px] tracking-widest text-emerald-500/80 uppercase">
                  NODE_ID // {Math.random().toString(16).substring(2, 10).toUpperCase()}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

        </motion.div>

      </div>
    </section>
  );
}
