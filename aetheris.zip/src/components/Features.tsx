/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState } from 'react';
import { motion } from 'motion/react';
import { Shield, Layers, Cpu, Compass, Orbit, Sparkles } from 'lucide-react';
import { FeatureCard } from '../types';

// Interactive Card Component with Real-Time 3D Tilt Mechanics
function PerspectiveCard({ card, index }: { card: FeatureCard; index: number; key?: string }) {
  const cardRef = useRef<HTMLDivElement | null>(null);
  const [rotate, setRotate] = useState({ x: 0, y: 0 });
  const [glowPos, setGlowPos] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    
    // Relative mouse coordinates from -0.5 to 0.5
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    
    // Rotate values (max 12 degrees)
    setRotate({
      x: -y * 18,
      y: x * 18,
    });

    // Cursor position in pixels for glowing flashlights
    setGlowPos({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    });
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setRotate({ x: 0, y: 0 });
  };

  const renderIcon = (iconName: string) => {
    const sizeClass = "w-6 h-6 text-cyan-400 group-hover:scale-110 group-hover:text-cyan-300 transition-all duration-500";
    switch (iconName) {
      case 'shield': return <Shield className={sizeClass} />;
      case 'layers': return <Layers className={sizeClass} />;
      case 'cpu': return <Cpu className={sizeClass} />;
      case 'compass': return <Compass className={sizeClass} />;
      default: return <Sparkles className={sizeClass} />;
    }
  };

  return (
    <motion.div
      initial={{ y: 75, opacity: 0, rotateX: 18, rotateY: -5, scale: 0.94, filter: 'blur(6px)' }}
      whileInView={{ y: 0, opacity: 1, rotateX: 0, rotateY: 0, scale: 1, filter: 'blur(0px)' }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 1.2, delay: index * 0.1, ease: [0.16, 1, 0.3, 1] }}
      className="perspective-[1200px] transform-gpu"
    >
      <div
        ref={cardRef}
        onMouseMove={handleMouseMove}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={handleMouseLeave}
        style={{
          transform: isHovered
            ? `rotateX(${rotate.x}deg) rotateY(${rotate.y}deg) scale(1.025)`
            : 'rotateX(0deg) rotateY(0deg) scale(1)',
          transition: isHovered ? 'none' : 'transform 0.5s cubic-bezier(0.16, 1, 0.3, 1)',
        }}
        className="relative h-full flex flex-col justify-between p-8 rounded-xl border border-white/10 bg-white/5 backdrop-blur-xl overflow-hidden group cursor-pointer shadow-lg shadow-black/40 hover:border-cyan-400/40 hover:shadow-cyan-950/10 transition-all duration-300"
      >
        {/* Ambient top-right blur orb from theme */}
        <div className="absolute -top-10 -right-10 w-24 h-24 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Dynamic Interactive Flashlight Radial Glow overlay */}
        <div
          className="absolute inset-0 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity duration-500 z-0"
          style={{
            background: `radial-gradient(circle 220px at ${glowPos.x}px ${glowPos.y}px, ${card.glowColor}, transparent 80%)`,
          }}
        />

        {/* Card Content */}
        <div className="relative z-10">
          
          {/* Header Row */}
          <div className="flex items-center justify-between mb-6">
            <div className="w-10 h-10 flex items-center justify-center rounded-lg border border-white/10 bg-white/5 group-hover:border-cyan-500/30 transition-all duration-500 shadow-inner">
              {renderIcon(card.icon)}
            </div>
            <span className="text-[9px] text-cyan-400 font-bold uppercase tracking-widest italic">
              {card.category}
            </span>
          </div>

          {/* Title & Description */}
          <h3 className="font-sans text-[15px] font-bold text-white tracking-tight mb-2.5 group-hover:text-cyan-200 transition-colors">
            {card.title}
          </h3>
          <p className="font-sans text-[12px] text-white/70 leading-relaxed font-light group-hover:text-white transition-colors">
            {card.description}
          </p>

        </div>

        {/* Bottom indicator line matching theme */}
        <div className="mt-6 w-5 h-[1.5px] bg-white/30 group-hover:w-full transition-all duration-500 ease-out" />

      </div>
    </motion.div>
  );
}

export default function Features() {
  const features: FeatureCard[] = [
    {
      id: 'f1',
      icon: 'cpu',
      title: 'Quantum Vector Space',
      description: 'Generates high-fidelity visual trajectories in native coordinate spaces, reducing overhead while maximizing detail rendering.',
      category: 'Core Graphics',
      glowColor: 'rgba(6, 182, 212, 0.12)', // Cyan
    },
    {
      id: 'f2',
      icon: 'layers',
      title: 'Spatial Orchestration',
      description: 'Seamlessly tracks client scroll inputs to animate element matrices, mapping depths and coordinate frames smoothly.',
      category: 'Motion Pipeline',
      glowColor: 'rgba(139, 92, 246, 0.12)', // Violet
    },
    {
      id: 'f3',
      icon: 'shield',
      title: 'Atmospheric Physics',
      description: 'Living starfields, dust vortices, and nebula gases compiled server-side to shift organically around client vectors.',
      category: 'Dynamics System',
      glowColor: 'rgba(234, 179, 8, 0.08)', // Gold
    },
    {
      id: 'f4',
      icon: 'compass',
      title: 'Chromatic Harmony',
      description: 'Deep obsidian backdrops paired with soft contrast scales, automatically scaling to suit surrounding lighting environments.',
      category: 'Interface Craft',
      glowColor: 'rgba(14, 116, 144, 0.15)', // Dark Cyan
    }
  ];

  return (
    <section id="features" className="relative py-28 md:py-36 w-full bg-[#030305] overflow-hidden">
      
      {/* Cinematic background glowing elements */}
      <div className="absolute top-1/4 left-[-10%] w-[35rem] h-[35rem] rounded-full bg-cyan-950/10 blur-[130px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-[-10%] w-[30rem] h-[30rem] rounded-full bg-indigo-950/10 blur-[150px] pointer-events-none" />
      
      {/* Decorative vertical gradient line separator */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1px] h-32 bg-gradient-to-b from-transparent via-cyan-500/25 to-transparent pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col items-center text-center mb-16 md:mb-24">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full border border-zinc-800 bg-zinc-950/40 text-zinc-500 font-mono text-[9px] tracking-widest uppercase mb-5">
            <Orbit className="w-3.5 h-3.5 text-cyan-400 animate-spin-slow" />
            <span>Tactile Systems Architecture</span>
          </div>
          <h2 className="font-sans text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight leading-tight">
            Designed for Immersion
          </h2>
          <p className="max-w-xl font-sans text-sm md:text-base text-zinc-400 font-normal mt-4 leading-relaxed">
            Every layer in the Aetheris pipeline was structured to emphasize spatial movement, translating passive layouts into dynamic storytelling.
          </p>
        </div>

        {/* Feature Cards Grid Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((card, index) => (
            <PerspectiveCard key={card.id} card={card} index={index} />
          ))}
        </div>

      </div>
    </section>
  );
}
